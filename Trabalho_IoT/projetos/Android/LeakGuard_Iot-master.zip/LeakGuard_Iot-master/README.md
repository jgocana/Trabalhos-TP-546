# LeakGuard IoT - Aplicación Android Nativa

**LeakGuard** es una aplicación Android nativa desarrollada en Kotlin con Jetpack Compose y Clean Architecture para la monitorización en tiempo real y control de alarmas de detección de fugas de agua conectada a un prototipo IoT basado en ESP32 via MQTT 3.1.1.

---

## 🚀 Arquitectura y Tecnologías

- **Lenguaje:** Kotlin nativo (exclusivo Android)
- **UI Framework:** Jetpack Compose + Material 3 (Idioma: Português do Brasil)
- **Arquitectura:** Clean Architecture (Domain, Data, Presentation, DI) + MVVM dentro de un único módulo `:app`
- **Asincronía & Flujos:** Kotlin Coroutines, `StateFlow`, `SharedFlow`, `collectAsStateWithLifecycle()`
- **Cliente MQTT:** HiveMQ MQTT Client v3.1.1 (`com.hivemq:hivemq-mqtt-client`)
- **Serialización:** Kotlinx Serialization (`kotlinx.serialization.json`)
- **Inyección de Dependencias:** Inyección manual via `AppContainer`

---

## ⚙️ Configuración MQTT

| Parámetro | Valor |
| :--- | :--- |
| **Broker** | `broker.emqx.io` |
| **Puerto** | `1883` |
| **Protocolo** | MQTT 3.1.1 (TCP) |
| **Topic Root** | `leakguard/jgocana-yverdecia-iot-device01` |
| **State Topic** | `leakguard/jgocana-yverdecia-iot-device01/state` |
| **Event Topic** | `leakguard/jgocana-yverdecia-iot-device01/event` |
| **History Topic** | `leakguard/jgocana-yverdecia-iot-device01/history` |
| **Connection Topic** | `leakguard/jgocana-yverdecia-iot-device01/connection` |
| **Command Topic** | `leakguard/jgocana-yverdecia-iot-device01/cmd` |

### Formato de Telemetría (`/state` JSON)
```json
{
  "water_detected": true,
  "buzzer": true,
  "muted": false
}
```

### Comandos de Control (`/cmd` Texto plano)
- `SILENCE`: Desactiva el buzzer sin detener la detección del sensor de agua.
- `UNMUTE`: Reorganiza y activa el sonido de la alarma en caso de fuga.
- `GET_STATUS`: Solicita el estado actual al ESP32.
- `GET_HISTORY`: Solicita el historial de eventos al ESP32.

---

## 🛠️ Estructura del Proyecto

```text
app/src/main/java/br/inatel/mtel/leakguardiot/
│
├── data/
│   ├── dto/
│   │   └── LeakGuardStateDto.kt
│   ├── mqtt/
│   │   ├── MqttClientManager.kt
│   │   └── MqttConfig.kt
│   └── repository/
│       └── LeakGuardRepositoryImpl.kt
│
├── domain/
│   ├── model/
│   │   ├── ConnectionState.kt
│   │   ├── LeakGuardState.kt
│   │   ├── MqttMessage.kt
│   │   └── RecentEvent.kt
│   ├── repository/
│   │   └── LeakGuardRepository.kt
│   └── usecase/
│       ├── ObserveLeakGuardUseCase.kt
│       ├── SilenceAlarmUseCase.kt
│       └── UnmuteAlarmUseCase.kt
│
├── presentation/
│   ├── components/
│   │   ├── CommandButtons.kt
│   │   ├── ConnectionHeader.kt
│   │   ├── InfoCard.kt
│   │   ├── RecentEventsCard.kt
│   │   └── StatusMainCard.kt
│   └── dashboard/
│       ├── DashboardScreen.kt
│       ├── DashboardUiState.kt
│       └── DashboardViewModel.kt
│
├── di/
│   └── AppContainer.kt
│
├── LeakGuardApplication.kt
└── MainActivity.kt
```

---

## 🧪 Pruebas Unitarias

El proyecto cuenta con pruebas unitarias para deserialización JSON y lógica de ViewModel/Repositorio:
- `JsonParsingTest.kt`: Pruebas de deserialización de JSON válido, JSON con fuga, y manejo de JSON malformado.
- `DashboardViewModelTest.kt`: Pruebas de estados del sensor (seco/fuga), envío de comandos SILENCE/UNMUTE, eventos de conexión/desconexión y timeout por telemetría desactualizada (>10 segundos).

---

## 📦 Generación de APK Debug

Para compilar y generar el archivo APK ejecutable:
```bash
./gradlew app:assembleDebug
```
Ubicación del ejecutable generado:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 🧪 Guía de Pruebas con ESP32 / MQTTX

1. Conectar el dispositivo Android a Internet.
2. Abrir la aplicación **LeakGuard**. Se conectará automáticamente al broker `broker.emqx.io:1883`.
3. Usar **MQTTX Web** o el prototipo **ESP32**:
   - Suscribirse a `leakguard/jgocana-yverdecia-iot-device01/cmd`.
   - Publicar en `leakguard/jgocana-yverdecia-iot-device01/state` el siguiente JSON para simular fuga:
     ```json
     {
       "water_detected": true,
       "buzzer": true,
       "muted": false
     }
     ```
   - En la app se mostrará la tarjeta roja **"Vazamento detectado!"** y el evento en la lista.
   - Presionar **"Silenciar alarme"** en la app. La app enviará `SILENCE` al tópico `leakguard/jgocana-yverdecia-iot-device01/cmd`.
   - Publicar la respuesta del ESP32 con `muted: true`:
     ```json
     {
       "water_detected": true,
       "buzzer": false,
       "muted": true
     }
     ```
   - La app confirmará el estado silenciado y actualizará los botones de control.
