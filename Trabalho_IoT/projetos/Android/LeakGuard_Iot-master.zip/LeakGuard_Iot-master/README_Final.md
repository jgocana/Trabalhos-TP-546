# 💧 LeakGuard IoT

**Sistema de detecção e monitoramento de vazamentos de água com ESP32, MQTT e aplicativo Android nativo.**

Projeto acadêmico desenvolvido para a disciplina de **Internet das Coisas (IoT)**, com entrega prevista para **11 de novembro de 2026**.

O LeakGuard IoT detecta a presença de água por meio de um sensor conectado a um ESP32, aciona um alarme sonoro local e transmite informações em tempo real utilizando o protocolo MQTT. Um aplicativo Android permite acompanhar o dispositivo, controlar o buzzer, consultar o histórico de vazamentos e visualizar estatísticas dos incidentes registrados.

> **Escopo:** protótipo educacional de baixo custo. Não se trata de um dispositivo certificado de proteção contra inundações ou de um produto comercial.

---

## 📋 Funcionalidades

### ESP32 e monitoramento físico

- Detecção da presença de água com **Grove Water Sensor**.
- Confirmação temporal da leitura: aproximadamente **400 ms** para detectar água e **800 ms** para confirmar que o sensor voltou a ficar seco.
- Alarme acústico intermitente com **Grove Buzzer**, sem bloquear o monitoramento ou a comunicação.
- Silenciamento e reativação do alarme por comandos remotos.
- Publicação periódica de telemetria, aproximadamente a cada **2 segundos**.
- Eventos de início (`LEAK_START`) e término (`LEAK_END`) de vazamentos.
- Registro da quantidade de vazamentos e das respectivas durações.
- Armazenamento em memória não volátil (**NVS/Preferences**) dos acumuladores e dos **últimos 8 vazamentos concluídos**.
- Sincronização do relógio via **NTP**, quando disponível.
- Reconexão automática à rede Wi-Fi e ao broker MQTT.

### Aplicativo Android

O aplicativo foi desenvolvido em **Kotlin**, com **Jetpack Compose** e **Material Design 3**, e possui três telas:

| Tela | Funcionalidades |
| --- | --- |
| **Painel** | Estado do sensor, presença de água, buzzer, silenciamento, indicadores do ESP32, conexão MQTT, eventos recentes e comandos de controle. |
| **Histórico** | Listagem dos incidentes concluídos, com identificador, início, fim e duração, armazenados localmente. |
| **Estatísticas** | Total de vazamentos, tempo acumulado, duração média, maior duração, gráfico dos últimos 7 dias e comparação dos últimos 5 incidentes. |

Outros recursos:

- Recepção de informações MQTT em tempo real.
- Solicitação manual de estado e histórico do ESP32.
- Sincronização automática de incidentes MQTT → **Room Database**.
- Prevenção de registros duplicados por `(deviceId, eventId)`.
- Atualização reativa das telas de histórico e estatísticas utilizando `Flow`.
- Consulta aos incidentes já armazenados **mesmo sem conexão à Internet**.
- Indicação de conectividade do ESP32 usando **Last Will and Testament (LWT)** e atualização recente de telemetria.

---

## 🏗️ Arquitetura da solução

```mermaid
flowchart TD
    S[Sensor de água Grove] --> E[ESP32]
    E --> B[Buzzer local]
    E <-->|Wi-Fi / MQTT| M[Broker EMQX]
    M <-->|MQTT| A[Aplicativo Android]
    M <-->|MQTT / WebSocket| X[MQTTX]
    A <--> R[(Room Database)]
    R --> H[Histórico e estatísticas]
```

**Fluxo de um incidente:**

1. O sensor detecta água e o ESP32 confirma a condição.
2. O buzzer emite um alarme local, enquanto o ESP32 publica telemetria e `LEAK_START`.
3. O aplicativo atualiza o painel e pode enviar `SILENCE` ou `UNMUTE`.
4. Quando o sensor seca, o ESP32 registra a duração, publica `LEAK_END` e atualiza `/history`.
5. O aplicativo sincroniza os incidentes com o Room; histórico e estatísticas são atualizados automaticamente.

O funcionamento **local do sensor e do buzzer não depende do celular**. A comunicação remota depende da conectividade Wi-Fi e do broker MQTT.

---

## 🔌 Componentes de hardware

| Componente | Utilização |
| --- | --- |
| ESP32 DOIT DevKit V1 | Leitura do sensor, processamento, armazenamento e comunicação Wi-Fi/MQTT. |
| Grove Water Sensor | Detecção de contato com água. |
| Grove Buzzer | Alarme sonoro local. |
| Protoboard e jumpers | Montagem das conexões. |
| Cabo USB e fonte de alimentação | Alimentação e programação do ESP32. |
| Smartphone Android | Execução do aplicativo. |

### Conexões principais

| Dispositivo | Pino do ESP32 | Observação |
| --- | --- | --- |
| Sinal do sensor de água | **GPIO 34** | Leitura digital; no firmware, `LOW` indica presença de água. |
| Sinal do buzzer | **GPIO 23** | Saída para o alarme acústico. |
| GND dos módulos | **GND** | Terra comum. |
| Alimentação dos módulos | **Conforme especificação do módulo** | Verificar a tensão e a compatibilidade elétrica antes de energizar. |

> **Atenção:** as entradas do ESP32 não são tolerantes a 5 V. Não aplique 5 V diretamente ao GPIO 34. Confira a alimentação e o nível de saída do sensor utilizado na montagem.

---

## 📡 Comunicação MQTT

O sistema utiliza comunicação **publish/subscribe** com um broker público de demonstração.

| Parâmetro | Valor |
| --- | --- |
| Broker | `broker.emqx.io` |
| Porta MQTT TCP | `1883` |
| Tópico raiz | `leakguard/jgocana-yverdecia-iot-device01` |
| Protocolo | MQTT 3.1.1 |
| Cliente auxiliar | MQTTX |

### Tópicos

| Tópico (sufixo) | Direção | Conteúdo | Retain |
| --- | --- | --- | --- |
| `/state` | ESP32 → clientes | Estado atual e contadores | Sim |
| `/event` | ESP32 → clientes | `LEAK_START` / `LEAK_END` | Não |
| `/history` | ESP32 → clientes | Últimos 8 incidentes concluídos | Sim |
| `/connection` | ESP32 / broker → clientes | `online` / `offline` (LWT) | Sim |
| `/cmd` | Aplicativo / MQTTX → ESP32 | Comandos de texto | Não utilizar |

### Exemplo de estado (`/state`)

```json
{
  "water_detected": false,
  "buzzer": false,
  "muted": false,
  "leak_count": 3,
  "current_leak_seconds": 0,
  "total_leak_seconds": 120,
  "updated_at_unix": 1794064800
}
```

### Exemplo de evento (`/event`)

```json
{
  "type": "LEAK_END",
  "id": 3,
  "timestamp_unix": 1794064745,
  "duration_seconds": 45
}
```

### Exemplo de histórico (`/history`)

```json
{
  "count": 2,
  "events": [
    {
      "id": 3,
      "start_unix": 1794064700,
      "end_unix": 1794064745,
      "duration_seconds": 45
    },
    {
      "id": 2,
      "start_unix": 1794064500,
      "end_unix": 1794064530,
      "duration_seconds": 30
    }
  ]
}
```

Os timestamps são representados em **segundos Unix**. O valor `0` pode indicar que o ESP32 ainda não dispõe de uma referência NTP válida.

### Comandos disponíveis (`/cmd`)

Enviar um dos seguintes textos para:

`leakguard/jgocana-yverdecia-iot-device01/cmd`

| Comando | Ação |
| --- | --- |
| `SILENCE` | Silencia o buzzer durante um vazamento ativo, sem desligar a detecção. |
| `UNMUTE` | Reativa o alarme, caso o vazamento continue ativo. |
| `GET_STATUS` | Solicita uma nova publicação em `/state`. |
| `GET_HISTORY` | Solicita uma nova publicação em `/history`. |

Os comandos são mensagens de **texto puro**, sem JSON, e devem ser enviados com **retain desativado**. O tópico `/cmd` não deve armazenar comandos retidos.

### Testar com MQTTX

1. Conecte o MQTTX ao broker `broker.emqx.io` na porta `1883`. Se utilizar um cliente Web, use a conexão WebSocket compatível disponibilizada pelo broker.
2. Inscreva-se em `leakguard/jgocana-yverdecia-iot-device01/#` para acompanhar os tópicos do dispositivo.
3. Molhe o sensor e observe as atualizações de `/state` e `/event`.
4. Publique `SILENCE`, `UNMUTE`, `GET_STATUS` ou `GET_HISTORY` em `/cmd`.
5. Observe as respostas e o histórico após a finalização do vazamento.

---

## 🛠️ Tecnologias utilizadas

**Firmware**

- ESP32 e framework **Arduino**.
- **PlatformIO** para desenvolvimento e upload.
- **PubSubClient** para MQTT.
- **WiFi** para conectividade.
- **Preferences / NVS** para persistência.
- **NTP** para sincronização de horário.

**Aplicativo Android**

- **Kotlin** e **Jetpack Compose**.
- **Material Design 3**.
- Arquitetura **MVVM** com separação em camadas.
- **HiveMQ MQTT Client**.
- **Coroutines**, **StateFlow** e **Flow**.
- **Room Database** para persistência local.
- **Kotlinx Serialization** para processamento de JSON.

---

## 🚀 Como executar

### 1. Preparar o firmware do ESP32

1. Instale o [Visual Studio Code](https://code.visualstudio.com/) e a extensão [PlatformIO](https://platformio.org/).
2. Abra a pasta do projeto de firmware (por exemplo, `trabalho_Iot/`).
3. Configure as credenciais locais de Wi-Fi e o tópico MQTT em `include/secrets.h`.
4. Conecte o ESP32 via USB.
5. Selecione o ambiente `esp32doit-devkit-v1`, compile e faça o upload pelo PlatformIO.
6. Abra o monitor serial a **115200 baud** e acompanhe a conexão Wi-Fi/MQTT.

**Exemplo de arquivo `include/secrets.h`** (usar seus próprios dados):

```cpp
#pragma once

constexpr char WIFI_SSID[] = "SUA_REDE_WIFI";
constexpr char WIFI_PASSWORD[] = "SUA_SENHA_WIFI";
constexpr char MQTT_TOPIC_ROOT[] = "leakguard/jgocana-yverdecia-iot-device01";
```

**Não inclua credenciais reais no repositório público.** Adicione `include/secrets.h` ao `.gitignore`. Caso o repositório contenha o firmware em uma subpasta, ajuste a regra para esse caminho. Um arquivo `secrets.example.h`, sem senhas, pode ser versionado como modelo.

### 2. Executar o aplicativo Android

1. Abra o projeto Android (por exemplo, `LeakGuardIot/`) no **Android Studio**.
2. Aguarde a sincronização do Gradle.
3. Conecte um smartphone Android ou utilize um emulador com acesso à Internet.
4. Execute o módulo **`app`**.
5. Verifique se o aplicativo utiliza o mesmo broker e o mesmo tópico raiz configurados no firmware.
6. Abra as abas **Painel**, **Histórico** e **Estatísticas**.

> A configuração atual do broker e do identificador do dispositivo está definida no código Android em `data/mqtt/MqttConfig.kt`. A configuração precisa corresponder ao firmware.

### 3. Demonstração prática

1. Inicie o ESP32 e o aplicativo Android.
2. Confira o estado de conexão e as informações do sensor no **Painel**.
3. Molhe o sensor: o ESP32 deve identificar o vazamento, acionar o buzzer e enviar informações via MQTT.
4. Utilize **SILENCE** no aplicativo e verifique que o buzzer é silenciado sem interromper a detecção.
5. Utilize **UNMUTE**, mantendo o sensor molhado, para reativar a sinalização acústica.
6. Seque o sensor: o ESP32 encerra o incidente e publica o histórico atualizado.
7. Abra **Histórico** e confira o registro concluído.
8. Abra **Estatísticas** e observe os indicadores e gráficos atualizados.
9. Repita o processo para gerar novos incidentes e demonstrar o armazenamento acumulativo.

---

## 💾 Persistência e análise dos dados

O projeto utiliza duas formas de armazenamento complementares:

| Local | O que é armazenado | Finalidade |
| --- | --- | --- |
| **ESP32 / NVS** | Contadores, tempo acumulado e últimos 8 incidentes concluídos | Recuperação de informações no dispositivo após reinicializações. |
| **Android / Room** | Incidentes sincronizados e identificados por dispositivo e ID | Histórico acumulativo, consulta offline e estatísticas. |

Quando o aplicativo recebe `/history`, insere os incidentes ainda não presentes no Room. O índice único por **`deviceId` + `eventId`** evita duplicar entradas já recebidas em uma operação normal.

O aplicativo calcula indicadores como quantidade total, duração acumulada, duração média, maior incidente e distribuição diária a partir dos registros locais.

**Importante:** o histórico da aplicação representa os incidentes **efetivamente recebidos e armazenados pelo Android**. Se o aplicativo ficar desconectado por muito tempo e o ESP32 sobrescrever incidentes antigos de seu buffer de oito registros, esses incidentes podem não ser recuperados posteriormente.

---

## 📁 Organização do repositório

A organização abaixo é **sugerida** para reunir firmware e aplicativo no mesmo repositório. Adapte os diretórios aos nomes reais utilizados no GitHub.

```text
LeakGuard-IoT/
├── README.md
├── firmware/                     # Projeto PlatformIO (trabalho_Iot)
│   ├── platformio.ini
│   ├── include/
│   │   └── secrets.example.h      # Modelo sem credenciais reais (opcional)
│   └── src/
│       └── main.cpp
└── android/                      # Projeto Android Studio (LeakGuardIot)
    ├── app/
    │   └── src/main/
    │       └── java/br/inatel/mtel/leakguardiot/
    ├── gradle/
    ├── build.gradle.kts
    └── settings.gradle.kts
```

No aplicativo, as principais áreas de código são `data` (MQTT, DTOs, Room e sincronização), `domain` (modelos e repositórios), `presentation` (Painel, Histórico e Estatísticas) e `di` (injeção manual de dependências).

---

## ⚠️ Limitações do protótipo

- O broker público `broker.emqx.io` é utilizado **apenas para demonstração**; a porta `1883` não oferece criptografia TLS nem autenticação específica para o projeto.
- O ESP32 mantém somente os **últimos 8 incidentes concluídos** na NVS.
- O histórico no Android depende dos incidentes que o aplicativo conseguiu receber do ESP32 ou do broker.
- A consulta a dados já armazenados funciona offline, mas **novos eventos não são recebidos quando o processo do aplicativo está encerrado**.
- Caso o armazenamento NVS seja apagado, IDs antigos poderão ser reutilizados. Nesse caso, a deduplicação por `(deviceId, eventId)` poderá impedir que incidentes novos com IDs repetidos sejam adicionados ao Room.
- Timestamps absolutos dependem da sincronização NTP; sem ela, podem estar indisponíveis.
- O sensor resistivo é adequado para demonstração e pode exigir manutenção e calibração em outros ambientes.
- O protótipo não inclui backend próprio, armazenamento em nuvem ou notificações push garantidas.

---

## 🎓 Objetivo acadêmico

Demonstrar a integração prática entre **sistemas embarcados**, **sensoriamento físico**, **redes Wi-Fi**, **protocolo MQTT**, **persistência de dados** e **desenvolvimento Android nativo**.

O cenário de demonstração permite acompanhar um vazamento desde a detecção no sensor até a atuação do buzzer, a publicação no broker MQTT, a visualização no aplicativo e o registro histórico para análise posterior.

**LeakGuard IoT — Detecção local, monitoramento remoto e histórico de vazamentos.**
