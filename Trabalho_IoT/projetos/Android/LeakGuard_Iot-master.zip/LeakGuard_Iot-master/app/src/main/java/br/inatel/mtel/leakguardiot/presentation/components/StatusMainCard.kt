package br.inatel.mtel.leakguardiot.presentation.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability

@Composable
fun StatusMainCard(
    waterDetected: Boolean?,
    deviceAvailability: DeviceAvailability,
    modifier: Modifier = Modifier
) {
    val isOnline = deviceAvailability == DeviceAvailability.ONLINE
    val isLeakActive = isOnline && waterDetected == true
    val isLeakOutdated = !isOnline && waterDetected == true
    val isNormalActive = isOnline && waterDetected == false

    val backgroundColor by animateColorAsState(
        targetValue = when {
            isLeakActive -> Color(0xFFFFEBEE)
            isLeakOutdated -> Color(0xFFFFF3E0)
            isNormalActive -> Color(0xFFE8F5E9)
            else -> Color(0xFFECEFF1)
        },
        animationSpec = tween(durationMillis = 300),
        label = "bgColor"
    )

    val contentColor by animateColorAsState(
        targetValue = when {
            isLeakActive -> Color(0xFFC62828)
            isLeakOutdated -> Color(0xFFE65100)
            isNormalActive -> Color(0xFF2E7D32)
            else -> Color(0xFF455A64)
        },
        animationSpec = tween(durationMillis = 300),
        label = "contentColor"
    )

    val titleText = when {
        isLeakActive -> "Vazamento detectado!"
        isLeakOutdated -> "Vazamento no último estado"
        isNormalActive -> "Ambiente seguro"
        else -> "Dispositivo sem comunicação"
    }

    val subtitleText = when {
        isLeakActive -> "Presença de água identificada no sensor"
        isLeakOutdated -> "Último registro indicava vazamento (dados desatualizados)"
        isNormalActive -> "Nenhum vazamento detectado"
        deviceAvailability == DeviceAvailability.OFFLINE -> "ESP32 desconectado do broker"
        deviceAvailability == DeviceAvailability.SEM_SINAL -> "Sem telemetria recente do ESP32"
        else -> "Aguardando sinal do ESP32"
    }

    val icon = when {
        isLeakActive || isLeakOutdated -> Icons.Default.Warning
        isNormalActive -> Icons.Default.CheckCircle
        else -> Icons.Default.CloudOff
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor,
            contentColor = contentColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = titleText,
                modifier = Modifier.size(56.dp),
                tint = contentColor
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = titleText,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = contentColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitleText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = contentColor.copy(alpha = 0.85f)
                )
            }
        }
    }
}
