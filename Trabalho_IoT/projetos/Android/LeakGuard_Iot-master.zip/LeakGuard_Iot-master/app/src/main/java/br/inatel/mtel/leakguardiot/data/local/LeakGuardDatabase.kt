package br.inatel.mtel.leakguardiot.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import br.inatel.mtel.leakguardiot.data.local.dao.LeakEventDao
import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity

@Database(
    entities = [LeakEventEntity::class],
    version = 1,
    exportSchema = false
)
abstract class LeakGuardDatabase : RoomDatabase() {

    abstract fun leakEventDao(): LeakEventDao

    companion object {
        const val DATABASE_NAME = "leakguard_database.db"

        @Volatile
        private var INSTANCE: LeakGuardDatabase? = null

        fun getInstance(context: Context): LeakGuardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LeakGuardDatabase::class.java,
                    DATABASE_NAME
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
