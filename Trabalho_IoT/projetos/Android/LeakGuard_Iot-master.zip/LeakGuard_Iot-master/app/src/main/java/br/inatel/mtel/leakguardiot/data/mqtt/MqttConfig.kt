package br.inatel.mtel.leakguardiot.data.mqtt

import java.util.UUID

object MqttConfig {
    const val BROKER_HOST = "broker.emqx.io"
    const val BROKER_PORT = 1883

    const val DEVICE_ID = "jgocana-yverdecia-iot-device01"
    const val TOPIC_ROOT = "leakguard/$DEVICE_ID"

    const val STATE_TOPIC = "$TOPIC_ROOT/state"
    const val EVENT_TOPIC = "$TOPIC_ROOT/event"
    const val HISTORY_TOPIC = "$TOPIC_ROOT/history"
    const val CONNECTION_TOPIC = "$TOPIC_ROOT/connection"
    const val CMD_TOPIC = "$TOPIC_ROOT/cmd"

    const val CMD_SILENCE = "SILENCE"
    const val CMD_UNMUTE = "UNMUTE"
    const val CMD_GET_STATUS = "GET_STATUS"
    const val CMD_GET_HISTORY = "GET_HISTORY"

    fun generateClientId(): String {
        return "LeakGuard-Android-" + UUID.randomUUID().toString().take(8)
    }
}
