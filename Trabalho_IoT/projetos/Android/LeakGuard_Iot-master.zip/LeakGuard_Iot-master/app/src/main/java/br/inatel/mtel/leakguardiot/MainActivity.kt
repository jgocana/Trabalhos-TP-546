package br.inatel.mtel.leakguardiot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import br.inatel.mtel.leakguardiot.presentation.dashboard.DashboardScreen
import br.inatel.mtel.leakguardiot.presentation.dashboard.DashboardViewModel
import br.inatel.mtel.leakguardiot.presentation.history.HistoryScreen
import br.inatel.mtel.leakguardiot.presentation.history.HistoryViewModel
import br.inatel.mtel.leakguardiot.presentation.statistics.StatisticsScreen
import br.inatel.mtel.leakguardiot.presentation.statistics.StatisticsViewModel
import br.inatel.mtel.leakguardiot.ui.theme.LeakGuardIotTheme

enum class AppTab {
    DASHBOARD,
    HISTORY,
    STATISTICS
}

class MainActivity : ComponentActivity() {

    private val dashboardViewModel: DashboardViewModel by viewModels {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val appContainer = (application as LeakGuardApplication).appContainer
                return DashboardViewModel(
                    observeLeakGuardUseCase = appContainer.observeLeakGuardUseCase,
                    silenceAlarmUseCase = appContainer.silenceAlarmUseCase,
                    unmuteAlarmUseCase = appContainer.unmuteAlarmUseCase,
                    getDeviceStatusUseCase = appContainer.getDeviceStatusUseCase,
                    getDeviceHistoryUseCase = appContainer.getDeviceHistoryUseCase,
                    repository = appContainer.leakGuardRepository,
                    syncCoordinator = appContainer.leakHistorySyncCoordinator
                ) as T
            }
        }
    }

    private val historyViewModel: HistoryViewModel by viewModels {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val appContainer = (application as LeakGuardApplication).appContainer
                return HistoryViewModel(
                    leakHistoryRepository = appContainer.leakHistoryRepository
                ) as T
            }
        }
    }

    private val statisticsViewModel: StatisticsViewModel by viewModels {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val appContainer = (application as LeakGuardApplication).appContainer
                return StatisticsViewModel(
                    leakHistoryRepository = appContainer.leakHistoryRepository
                ) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LeakGuardIotTheme {
                var selectedTab by rememberSaveable { mutableStateOf(AppTab.DASHBOARD) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == AppTab.DASHBOARD,
                                onClick = { selectedTab = AppTab.DASHBOARD },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.Dashboard,
                                        contentDescription = "Painel"
                                    )
                                },
                                label = { Text("Painel") }
                            )

                            NavigationBarItem(
                                selected = selectedTab == AppTab.HISTORY,
                                onClick = { selectedTab = AppTab.HISTORY },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = "Histórico"
                                    )
                                },
                                label = { Text("Histórico") }
                            )

                            NavigationBarItem(
                                selected = selectedTab == AppTab.STATISTICS,
                                onClick = { selectedTab = AppTab.STATISTICS },
                                icon = {
                                    Icon(
                                        imageVector = Icons.Default.BarChart,
                                        contentDescription = "Estatísticas"
                                    )
                                },
                                label = { Text("Estatísticas") }
                            )
                        }
                    }
                ) { innerPadding ->
                    when (selectedTab) {
                        AppTab.DASHBOARD -> DashboardScreen(
                            viewModel = dashboardViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppTab.HISTORY -> HistoryScreen(
                            viewModel = historyViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                        AppTab.STATISTICS -> StatisticsScreen(
                            viewModel = statisticsViewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
