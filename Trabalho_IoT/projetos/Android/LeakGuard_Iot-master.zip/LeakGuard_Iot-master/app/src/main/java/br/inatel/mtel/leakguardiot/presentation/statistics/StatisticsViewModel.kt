package br.inatel.mtel.leakguardiot.presentation.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import br.inatel.mtel.leakguardiot.presentation.utils.TimeFormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class StatisticsViewModel(
    private val leakHistoryRepository: LeakHistoryRepository,
    private val deviceId: String = MqttConfig.DEVICE_ID
) : ViewModel() {

    private val _uiState = MutableStateFlow(StatisticsUiState())
    val uiState: StateFlow<StatisticsUiState> = _uiState.asStateFlow()

    init {
        observeStatisticsData()
    }

    private fun observeStatisticsData() {
        viewModelScope.launch {
            leakHistoryRepository.observeIncidents(deviceId).collect { incidentList ->
                val totalCount = incidentList.size
                val totalDurationSeconds = incidentList.sumOf { it.durationSeconds }
                val averageDurationSeconds = if (totalCount > 0) totalDurationSeconds / totalCount else 0L
                val longestDurationSeconds = incidentList.maxOfOrNull { it.durationSeconds } ?: 0L

                val last7DaysCounts = calculateLast7Days(incidentList)
                val last5LeakBars = calculateLast5LeakBars(incidentList)

                _uiState.update { currentState ->
                    currentState.copy(
                        totalCount = totalCount,
                        totalDurationSeconds = totalDurationSeconds,
                        averageDurationSeconds = averageDurationSeconds,
                        longestDurationSeconds = longestDurationSeconds,
                        last7DaysCounts = last7DaysCounts,
                        last5LeakBars = last5LeakBars,
                        isLoading = false
                    )
                }
            }
        }
    }

    private fun calculateLast7Days(incidents: List<LeakIncident>): List<DayLeakCount> {
        val result = mutableListOf<DayLeakCount>()
        val dayFormatter = SimpleDateFormat("EEE", Locale.forLanguageTag("pt-BR"))
        val keyFormatter = SimpleDateFormat("yyyyMMdd", Locale.getDefault())

        val dayBuckets = LinkedHashMap<String, Pair<String, Int>>()

        // Initialize 7 days ending today
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance(Locale.getDefault())
            cal.add(Calendar.DAY_OF_YEAR, -i)
            val key = keyFormatter.format(cal.time)
            val rawLabel = dayFormatter.format(cal.time).replace(".", "").replaceFirstChar { it.uppercase() }
            dayBuckets[key] = Pair(rawLabel, 0)
        }

        // Group incidents by day
        for (incident in incidents) {
            val unix = incident.startedAtUnix ?: incident.endedAtUnix
            if (unix != null && unix > 0) {
                val date = Date(unix * 1000L)
                val key = keyFormatter.format(date)
                if (dayBuckets.containsKey(key)) {
                    val current = dayBuckets[key]!!
                    dayBuckets[key] = Pair(current.first, current.second + 1)
                }
            }
        }

        for (entry in dayBuckets.values) {
            result.add(DayLeakCount(dayLabel = entry.first, count = entry.second))
        }

        return result
    }

    private fun calculateLast5LeakBars(incidents: List<LeakIncident>): List<RecentLeakBar> {
        val recent5 = incidents.take(5)
        if (recent5.isEmpty()) return emptyList()

        val maxDuration = recent5.maxOfOrNull { it.durationSeconds }?.takeIf { it > 0 } ?: 1L

        return recent5.map { incident ->
            val ratio = (incident.durationSeconds.toFloat() / maxDuration.toFloat()).coerceIn(0.12f, 1.0f)
            RecentLeakBar(
                eventId = incident.eventId,
                durationSeconds = incident.durationSeconds,
                formattedDuration = TimeFormatUtils.formatTotalLeakTime(incident.durationSeconds),
                ratio = ratio
            )
        }
    }
}
