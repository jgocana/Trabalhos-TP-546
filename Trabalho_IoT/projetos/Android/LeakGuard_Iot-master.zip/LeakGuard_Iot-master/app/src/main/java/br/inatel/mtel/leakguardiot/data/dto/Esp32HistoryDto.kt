package br.inatel.mtel.leakguardiot.data.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Esp32HistoryDto(
    @SerialName("count") val count: Int = 0,
    @SerialName("events") val events: List<Esp32HistoryEventDto> = emptyList()
)

@Serializable
data class Esp32HistoryEventDto(
    @SerialName("id") val id: Long = 0,
    @SerialName("start_unix") val startUnix: Long = 0,
    @SerialName("end_unix") val endUnix: Long = 0,
    @SerialName("duration_seconds") val durationSeconds: Long = 0
)
