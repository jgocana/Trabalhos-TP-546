package br.inatel.mtel.leakguardiot.domain.model

import android.os.SystemClock

data class Esp32ConnectionStatus(
    val isOnline: Boolean,
    val isRetained: Boolean,
    val receivedAtMillis: Long,
    val receivedAtMonotonic: Long = SystemClock.elapsedRealtime()
)
