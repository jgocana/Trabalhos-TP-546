package br.inatel.mtel.leakguardiot.data.mqtt

import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import com.hivemq.client.mqtt.MqttClient
import com.hivemq.client.mqtt.datatypes.MqttQos
import com.hivemq.client.mqtt.lifecycle.MqttClientConnectedContext
import com.hivemq.client.mqtt.lifecycle.MqttClientDisconnectedContext
import com.hivemq.client.mqtt.mqtt3.Mqtt3AsyncClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets

class MqttClientManager(
    private val host: String = MqttConfig.BROKER_HOST,
    private val port: Int = MqttConfig.BROKER_PORT,
    private val clientId: String = MqttConfig.generateClientId()
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _subscriptionsConfirmed = MutableStateFlow(false)
    val subscriptionsConfirmed: StateFlow<Boolean> = _subscriptionsConfirmed.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<MqttMessage>(replay = 1)
    val incomingMessages: SharedFlow<MqttMessage> = _incomingMessages.asSharedFlow()

    private val _incomingPayloads = MutableSharedFlow<String>(replay = 1)
    val incomingPayloads: SharedFlow<String> = _incomingPayloads.asSharedFlow()

    private var client: Mqtt3AsyncClient? = null

    fun connect() {
        if (_connectionState.value == ConnectionState.Connected || _connectionState.value == ConnectionState.Connecting) {
            return
        }
        _connectionState.value = ConnectionState.Connecting
        _subscriptionsConfirmed.value = false

        try {
            val mqttClient = MqttClient.builder()
                .useMqttVersion3()
                .automaticReconnect()
                .applyAutomaticReconnect()
                .serverHost(host)
                .serverPort(port)
                .identifier(clientId)
                .addConnectedListener { _: MqttClientConnectedContext ->
                    _connectionState.value = ConnectionState.Connected
                    subscribeToAllTopics()
                }
                .addDisconnectedListener { context: MqttClientDisconnectedContext ->
                    _subscriptionsConfirmed.value = false
                    if (context.source.name == "USER") {
                        _connectionState.value = ConnectionState.Disconnected
                    } else {
                        _connectionState.value = ConnectionState.Reconnecting
                    }
                }
                .buildAsync()

            client = mqttClient

            mqttClient.connect()
                .whenComplete { _, throwable: Throwable? ->
                    if (throwable != null) {
                        _subscriptionsConfirmed.value = false
                        _connectionState.value = ConnectionState.Error(
                            throwable.localizedMessage ?: "Falha ao conectar ao broker MQTT"
                        )
                    }
                }
        } catch (e: Exception) {
            _subscriptionsConfirmed.value = false
            _connectionState.value = ConnectionState.Error(
                e.localizedMessage ?: "Erro na inicialização MQTT"
            )
        }
    }

    private fun subscribeToAllTopics() {
        val currentClient = client ?: return
        _subscriptionsConfirmed.value = false

        val topicsToSubscribe = listOf(
            MqttConfig.STATE_TOPIC,
            MqttConfig.EVENT_TOPIC,
            MqttConfig.HISTORY_TOPIC,
            MqttConfig.CONNECTION_TOPIC
        )

        var confirmedCount = 0
        val totalTopics = topicsToSubscribe.size

        for (topicName in topicsToSubscribe) {
            currentClient.subscribeWith()
                .topicFilter(topicName)
                .qos(MqttQos.AT_LEAST_ONCE)
                .callback { publish ->
                    val topicReceived = publish.topic.toString()
                    val payload = String(publish.payloadAsBytes, StandardCharsets.UTF_8)
                    val isRetained = publish.isRetain
                    val message = MqttMessage(
                        topic = topicReceived,
                        payload = payload,
                        isRetained = isRetained,
                        receivedAtMillis = System.currentTimeMillis(),
                        receivedAtMonotonic = android.os.SystemClock.elapsedRealtime()
                    )
                    scope.launch {
                        _incomingMessages.emit(message)
                        if (topicReceived == MqttConfig.STATE_TOPIC) {
                            _incomingPayloads.emit(payload)
                        }
                    }
                }
                .send()
                .whenComplete { _, throwable: Throwable? ->
                    if (throwable == null) {
                        synchronized(this) {
                            confirmedCount++
                            if (confirmedCount >= totalTopics) {
                                _subscriptionsConfirmed.value = true
                            }
                        }
                    }
                }
        }
    }

    fun publishCommand(command: String, callback: (Result<Unit>) -> Unit) {
        val currentClient = client
        if (currentClient == null || _connectionState.value !is ConnectionState.Connected) {
            callback(Result.failure(IllegalStateException("MQTT não está conectado.")))
            return
        }

        currentClient.publishWith()
            .topic(MqttConfig.CMD_TOPIC)
            .payload(command.toByteArray(StandardCharsets.UTF_8))
            .qos(MqttQos.AT_LEAST_ONCE)
            .send()
            .whenComplete { _, throwable: Throwable? ->
                if (throwable != null) {
                    callback(Result.failure(throwable))
                } else {
                    callback(Result.success(Unit))
                }
            }
    }

    fun disconnect() {
        _subscriptionsConfirmed.value = false
        client?.disconnect()
        client = null
        _connectionState.value = ConnectionState.Disconnected
    }
}
