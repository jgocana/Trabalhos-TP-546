package br.inatel.mtel.leakguardiot.presentation.dashboard

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.inatel.mtel.leakguardiot.data.dto.Esp32EventDto
import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.data.sync.LeakHistorySyncCoordinator
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.EventType
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.model.RecentEvent
import br.inatel.mtel.leakguardiot.domain.model.SyncResult
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceHistoryUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceStatusUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.ObserveLeakGuardUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.SilenceAlarmUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.UnmuteAlarmUseCase
import br.inatel.mtel.leakguardiot.presentation.utils.TimeFormatUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.util.UUID

class DashboardViewModel(
    private val observeLeakGuardUseCase: ObserveLeakGuardUseCase,
    private val silenceAlarmUseCase: SilenceAlarmUseCase,
    private val unmuteAlarmUseCase: UnmuteAlarmUseCase,
    private val getDeviceStatusUseCase: GetDeviceStatusUseCase,
    private val getDeviceHistoryUseCase: GetDeviceHistoryUseCase,
    private val repository: LeakGuardRepository,
    private val syncCoordinator: LeakHistorySyncCoordinator? = null,
    private val json: Json = Json { ignoreUnknownKeys = true },
    private val timeProvider: () -> Long = { SystemClock.elapsedRealtime() }
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private var commandTimeoutJob: Job? = null
    private var statusTimeoutJob: Job? = null
    private var periodicCheckJob: Job? = null

    private var previousConnState: ConnectionState? = null
    private var previousAvailability: DeviceAvailability? = null

    private var lastLiveTelemetryMonotonic: Long? = null
    private var lastKnownLwtStatus: Esp32ConnectionStatus? = null
    private var previousLeakState: LeakGuardState? = null

    private var hasAutoRequestedStatusForSession = false
    private var statusRequestMonotonic: Long? = null

    init {
        connect()
        observeData()
        startPeriodicOnlineCheck()
    }

    fun connect() {
        viewModelScope.launch {
            repository.connect()
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            repository.disconnect()
        }
    }

    fun retryConnection() {
        connect()
    }

    private fun observeData() {
        // Observe Android Broker Connection State
        viewModelScope.launch {
            observeLeakGuardUseCase.connectionState.collect { connState ->
                handleConnectionStateChange(connState)
            }
        }

        // Observe Subscription Confirmations for Auto GET_STATUS
        viewModelScope.launch {
            repository.subscriptionsConfirmed.collect { isConfirmed ->
                _uiState.update { it.copy(subscriptionsConfirmed = isConfirmed) }
                if (isConfirmed && _uiState.value.connectionState is ConnectionState.Connected) {
                    if (!hasAutoRequestedStatusForSession) {
                        hasAutoRequestedStatusForSession = true
                        refreshStatus(isAutoSync = true)
                    }
                }
            }
        }

        // Observe ESP32 LWT Status (/connection topic)
        viewModelScope.launch {
            observeLeakGuardUseCase.esp32LwtStatus.collect { lwtStatus ->
                if (lwtStatus != null) {
                    handleEsp32LwtStatusChange(lwtStatus)
                }
            }
        }

        // Observe Telemetry State (/state topic)
        viewModelScope.launch {
            observeLeakGuardUseCase.leakGuardState.collect { newState ->
                if (newState != null) {
                    handleLeakGuardStateChange(newState)
                }
            }
        }

        // Observe Event Topic (/event topic) for LEAK_START and LEAK_END
        viewModelScope.launch {
            repository.incomingMessages.collect { message ->
                if (message.topic == MqttConfig.EVENT_TOPIC && !message.isRetained) {
                    try {
                        val eventDto = json.decodeFromString<Esp32EventDto>(message.payload)
                        val now = System.currentTimeMillis()
                        when (eventDto.type.uppercase()) {
                            "LEAK_START" -> {
                                val desc = if (eventDto.id > 0) "Vazamento detectado! (Fuga #${eventDto.id})" else "Vazamento detectado!"
                                _uiState.update { currentState ->
                                    val updatedEvents = addEvent(currentState.events, EventType.WATER_DETECTED, desc, now)
                                    currentState.copy(events = updatedEvents)
                                }
                            }
                            "LEAK_END" -> {
                                val formattedDuration = TimeFormatUtils.formatTotalLeakTime(eventDto.durationSeconds)
                                val desc = if (eventDto.id > 0) "Vazamento finalizado (Fuga #${eventDto.id} - $formattedDuration)" else "Vazamento finalizado ($formattedDuration)"
                                _uiState.update { currentState ->
                                    val updatedEvents = addEvent(currentState.events, EventType.WATER_CLEARED, desc, now)
                                    currentState.copy(events = updatedEvents)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // Ignore malformed event payload gracefully
                    }
                }
            }
        }

        // Observe Sync Coordinator Results (Single Source of Truth for History Sync)
        syncCoordinator?.let { coordinator ->
            viewModelScope.launch {
                coordinator.syncResultState.collect { result ->
                    _uiState.update { currentState ->
                        val msg = when (result) {
                            is SyncResult.Syncing -> "Sincronizando histórico..."
                            is SyncResult.Success -> {
                                if (result.newInsertedCount == 0) {
                                    "Histórico atualizado. Nenhum novo vazamento."
                                } else {
                                    "Histórico atualizado. ${result.newInsertedCount} novos vazamentos registrados."
                                }
                            }
                            is SyncResult.Error -> result.message
                            is SyncResult.Idle -> currentState.historyResponseMessage
                        }

                        val isPending = result is SyncResult.Syncing

                        currentState.copy(
                            syncResult = result,
                            isHistoryRequestPending = isPending,
                            historyResponseMessage = msg
                        )
                    }
                }
            }
        }
    }

    private fun handleConnectionStateChange(connState: ConnectionState) {
        val oldConn = previousConnState
        previousConnState = connState

        val now = timeProvider()
        var updatedEvents = _uiState.value.events

        if (connState !is ConnectionState.Connected) {
            hasAutoRequestedStatusForSession = false
        }

        if (oldConn != null && oldConn != connState) {
            if (connState is ConnectionState.Connected) {
                updatedEvents = addEvent(
                    updatedEvents,
                    EventType.CONNECTION_RESTORED,
                    "Conexão com o broker restabelecida",
                    System.currentTimeMillis()
                )
            } else if (connState is ConnectionState.Disconnected || connState is ConnectionState.Error) {
                updatedEvents = addEvent(
                    updatedEvents,
                    EventType.CONNECTION_LOST,
                    "Conexão com o broker perdida",
                    System.currentTimeMillis()
                )
            }
        }

        _uiState.update { currentState ->
            val availability = calculateDeviceAvailability(connState, lastKnownLwtStatus, lastLiveTelemetryMonotonic, now)
            updatedEvents = updateAvailabilityEvents(updatedEvents, availability, System.currentTimeMillis())
            currentState.copy(
                connectionState = connState,
                deviceAvailability = availability,
                events = updatedEvents
            )
        }
    }

    private fun handleEsp32LwtStatusChange(lwtStatus: Esp32ConnectionStatus) {
        lastKnownLwtStatus = lwtStatus
        recalculateAndEmitState()
    }

    private fun handleLeakGuardStateChange(newState: LeakGuardState) {
        val oldState = previousLeakState
        previousLeakState = newState

        var updatedEvents = _uiState.value.events
        val wallClockTimestamp = newState.receivedAt
        val monotonicTimestamp = newState.receivedAtMonotonic

        // Only non-retained telemetry counts as a live heartbeat
        if (!newState.isRetained) {
            lastLiveTelemetryMonotonic = monotonicTimestamp

            // Check if this live state satisfies an active status request
            val statusReqTime = statusRequestMonotonic
            if (statusReqTime != null && monotonicTimestamp >= statusReqTime) {
                statusTimeoutJob?.cancel()
                statusRequestMonotonic = null
                _uiState.update { it.copy(isStatusRequestPending = false) }
            }
        }

        // Check for water/alarm event transitions
        if (oldState == null) {
            if (newState.muted) {
                updatedEvents = addEvent(updatedEvents, EventType.ALARM_SILENCED, "Alarme silenciado", wallClockTimestamp)
            }
        } else {
            val hasRecentWaterEvent = updatedEvents.firstOrNull()?.let {
                (it.type == EventType.WATER_DETECTED || it.type == EventType.WATER_CLEARED) && (wallClockTimestamp - it.timestamp < 3000L)
            } ?: false

            if (!hasRecentWaterEvent) {
                if (!oldState.waterDetected && newState.waterDetected) {
                    updatedEvents = addEvent(updatedEvents, EventType.WATER_DETECTED, "Vazamento detectado!", wallClockTimestamp)
                } else if (oldState.waterDetected && !newState.waterDetected) {
                    updatedEvents = addEvent(updatedEvents, EventType.WATER_CLEARED, "Ambiente normalizado", wallClockTimestamp)
                }
            }

            if (!oldState.muted && newState.muted) {
                updatedEvents = addEvent(updatedEvents, EventType.ALARM_SILENCED, "Alarme silenciado", wallClockTimestamp)
            } else if (oldState.muted && !newState.muted) {
                updatedEvents = addEvent(updatedEvents, EventType.ALARM_UNMUTED, "Alarme reativado", wallClockTimestamp)
            }
        }

        // Check command confirmation for SILENCE/UNMUTE
        var isPending = _uiState.value.isCommandPending
        var pendingName = _uiState.value.pendingCommandName

        if (isPending) {
            if (pendingName == "SILENCE" && newState.muted) {
                isPending = false
                pendingName = null
                commandTimeoutJob?.cancel()
            } else if (pendingName == "UNMUTE" && !newState.muted) {
                isPending = false
                pendingName = null
                commandTimeoutJob?.cancel()
            }
        }

        val now = timeProvider()
        val availability = calculateDeviceAvailability(_uiState.value.connectionState, lastKnownLwtStatus, lastLiveTelemetryMonotonic, now)
        updatedEvents = updateAvailabilityEvents(updatedEvents, availability, System.currentTimeMillis())

        _uiState.update { currentState ->
            currentState.copy(
                waterDetected = newState.waterDetected,
                buzzerActive = newState.buzzerActive,
                muted = newState.muted,
                lastUpdatedTimestamp = newState.receivedAt,
                leakCount = newState.leakCount ?: currentState.leakCount,
                currentLeakSeconds = newState.currentLeakSeconds ?: currentState.currentLeakSeconds,
                totalLeakSeconds = newState.totalLeakSeconds ?: currentState.totalLeakSeconds,
                updatedAtUnix = newState.updatedAtUnix ?: currentState.updatedAtUnix,
                deviceAvailability = availability,
                isCommandPending = isPending,
                pendingCommandName = pendingName,
                events = updatedEvents
            )
        }
    }

    fun recalculateAndEmitState() {
        val now = timeProvider()
        _uiState.update { currentState ->
            val availability = calculateDeviceAvailability(
                currentState.connectionState,
                lastKnownLwtStatus,
                lastLiveTelemetryMonotonic,
                now
            )
            val updatedEvents = updateAvailabilityEvents(currentState.events, availability, System.currentTimeMillis())
            currentState.copy(
                deviceAvailability = availability,
                events = updatedEvents
            )
        }
    }

    private fun startPeriodicOnlineCheck() {
        periodicCheckJob?.cancel()
        periodicCheckJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                recalculateAndEmitState()
            }
        }
    }

    private fun calculateDeviceAvailability(
        brokerConn: ConnectionState,
        lwtStatus: Esp32ConnectionStatus?,
        lastLiveTelemetryMonotonic: Long?,
        nowMonotonic: Long
    ): DeviceAvailability {
        if (brokerConn !is ConnectionState.Connected) {
            return DeviceAvailability.DESCONHECIDO
        }

        val hasLwtOffline = lwtStatus?.isOnline == false &&
                (lastLiveTelemetryMonotonic == null || lwtStatus.receivedAtMonotonic >= lastLiveTelemetryMonotonic)

        if (hasLwtOffline) {
            return DeviceAvailability.OFFLINE
        }

        if (lastLiveTelemetryMonotonic == null) {
            return DeviceAvailability.DESCONHECIDO
        }

        val elapsed = nowMonotonic - lastLiveTelemetryMonotonic
        return if (elapsed in 0..10_000L) {
            DeviceAvailability.ONLINE
        } else {
            DeviceAvailability.SEM_SINAL
        }
    }

    private fun updateAvailabilityEvents(
        currentEvents: List<RecentEvent>,
        newAvailability: DeviceAvailability,
        nowWallClock: Long
    ): List<RecentEvent> {
        val oldAvailability = previousAvailability
        if (oldAvailability == newAvailability) return currentEvents
        previousAvailability = newAvailability

        if (oldAvailability == null) return currentEvents

        return when (newAvailability) {
            DeviceAvailability.ONLINE -> {
                addEvent(currentEvents, EventType.ESP32_SIGNAL_RESTORED, "Comunicação com ESP32 restabelecida", nowWallClock)
            }
            DeviceAvailability.OFFLINE -> {
                addEvent(currentEvents, EventType.ESP32_DISCONNECTED, "ESP32 desconectado", nowWallClock)
            }
            DeviceAvailability.SEM_SINAL -> {
                if (oldAvailability == DeviceAvailability.ONLINE) {
                    addEvent(currentEvents, EventType.ESP32_SIGNAL_LOST, "Comunicação com ESP32 perdida", nowWallClock)
                } else {
                    currentEvents
                }
            }
            else -> currentEvents
        }
    }

    private fun addEvent(
        currentList: List<RecentEvent>,
        type: EventType,
        description: String,
        timestamp: Long
    ): List<RecentEvent> {
        val newEvent = RecentEvent(
            id = UUID.randomUUID().toString(),
            type = type,
            timestamp = timestamp,
            description = description
        )
        return (listOf(newEvent) + currentList).take(30)
    }

    fun silenceAlarm() {
        if (_uiState.value.isCommandPending) return
        if (!_uiState.value.isDeviceOnline) {
            _uiState.update { it.copy(errorMessage = "Dispositivo sem comunicação. Não é possível silenciar.") }
            return
        }

        _uiState.update {
            it.copy(
                isCommandPending = true,
                pendingCommandName = "SILENCE",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = silenceAlarmUseCase()
            if (result.isFailure) {
                _uiState.update {
                    it.copy(
                        isCommandPending = false,
                        pendingCommandName = null,
                        errorMessage = "Falha ao enviar comando SILENCE: ${result.exceptionOrNull()?.localizedMessage}"
                    )
                }
            } else {
                scheduleCommandTimeout("SILENCE")
            }
        }
    }

    fun unmuteAlarm() {
        if (_uiState.value.isCommandPending) return
        if (!_uiState.value.isDeviceOnline) {
            _uiState.update { it.copy(errorMessage = "Dispositivo sem comunicação. Não é possível ativar alarme.") }
            return
        }

        _uiState.update {
            it.copy(
                isCommandPending = true,
                pendingCommandName = "UNMUTE",
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = unmuteAlarmUseCase()
            if (result.isFailure) {
                _uiState.update {
                    it.copy(
                        isCommandPending = false,
                        pendingCommandName = null,
                        errorMessage = "Falha ao enviar comando UNMUTE: ${result.exceptionOrNull()?.localizedMessage}"
                    )
                }
            } else {
                scheduleCommandTimeout("UNMUTE")
            }
        }
    }

    fun refreshStatus(isAutoSync: Boolean = false) {
        if (_uiState.value.isStatusRequestPending) return
        if (!isAutoSync && !_uiState.value.isDeviceOnline) {
            _uiState.update { it.copy(errorMessage = "Dispositivo sem comunicação. Não é possível atualizar estado.") }
            return
        }

        val requestTime = timeProvider()
        statusRequestMonotonic = requestTime

        _uiState.update {
            it.copy(
                isStatusRequestPending = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val result = getDeviceStatusUseCase()
            if (result.isFailure) {
                statusRequestMonotonic = null
                _uiState.update {
                    it.copy(
                        isStatusRequestPending = false,
                        errorMessage = "Falha ao enviar GET_STATUS: ${result.exceptionOrNull()?.localizedMessage}"
                    )
                }
            } else {
                scheduleStatusTimeout(requestTime)
            }
        }
    }

    fun requestHistory() {
        if (_uiState.value.isHistoryRequestPending) return
        if (!_uiState.value.isDeviceOnline) {
            _uiState.update { it.copy(errorMessage = "Dispositivo sem comunicação. Não é possível solicitar histórico.") }
            return
        }

        viewModelScope.launch {
            if (syncCoordinator != null) {
                syncCoordinator.requestManualHistory()
            } else {
                getDeviceHistoryUseCase()
            }
        }
    }

    private fun scheduleCommandTimeout(commandName: String) {
        commandTimeoutJob?.cancel()
        commandTimeoutJob = viewModelScope.launch {
            delay(5000L)
            _uiState.update { currentState ->
                if (currentState.isCommandPending && currentState.pendingCommandName == commandName) {
                    currentState.copy(
                        isCommandPending = false,
                        pendingCommandName = null,
                        errorMessage = "O comando foi enviado, mas não foi confirmado pelo dispositivo em tempo hábil."
                    )
                } else {
                    currentState
                }
            }
        }
    }

    private fun scheduleStatusTimeout(requestTime: Long) {
        statusTimeoutJob?.cancel()
        statusTimeoutJob = viewModelScope.launch {
            delay(5000L)
            _uiState.update { currentState ->
                if (currentState.isStatusRequestPending && statusRequestMonotonic == requestTime) {
                    statusRequestMonotonic = null
                    currentState.copy(
                        isStatusRequestPending = false,
                        errorMessage = "O comando GET_STATUS foi enviado, mas o ESP32 não respondeu em tempo hábil."
                    )
                } else {
                    currentState
                }
            }
        }
    }

    fun clearErrorMessage() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun clearHistoryResponseMessage() {
        _uiState.update { it.copy(historyResponseMessage = null) }
    }
}
