package br.inatel.mtel.leakguardiot.presentation.dashboard

import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability
import br.inatel.mtel.leakguardiot.domain.model.RecentEvent
import br.inatel.mtel.leakguardiot.domain.model.SyncResult

data class DashboardUiState(
    val connectionState: ConnectionState = ConnectionState.Disconnected,
    val subscriptionsConfirmed: Boolean = false,
    val deviceAvailability: DeviceAvailability = DeviceAvailability.DESCONHECIDO,
    val waterDetected: Boolean? = null,
    val buzzerActive: Boolean? = null,
    val muted: Boolean? = null,
    val lastUpdatedTimestamp: Long? = null,
    val leakCount: Long? = null,
    val currentLeakSeconds: Long? = null,
    val totalLeakSeconds: Long? = null,
    val updatedAtUnix: Long? = null,
    val isCommandPending: Boolean = false,
    val pendingCommandName: String? = null,
    val isStatusRequestPending: Boolean = false,
    val isHistoryRequestPending: Boolean = false,
    val syncResult: SyncResult = SyncResult.Idle,
    val historyResponseMessage: String? = null,
    val errorMessage: String? = null,
    val events: List<RecentEvent> = emptyList()
) {
    val isDeviceOnline: Boolean get() = deviceAvailability == DeviceAvailability.ONLINE
}
