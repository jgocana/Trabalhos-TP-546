package br.inatel.mtel.leakguardiot.data.repository

import br.inatel.mtel.leakguardiot.data.local.dao.LeakEventDao
import br.inatel.mtel.leakguardiot.data.local.mapper.toDomain
import br.inatel.mtel.leakguardiot.data.local.mapper.toEntity
import br.inatel.mtel.leakguardiot.domain.model.IncidentSaveResult
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LeakHistoryRepositoryImpl(
    private val dao: LeakEventDao
) : LeakHistoryRepository {

    override fun observeIncidents(deviceId: String): Flow<List<LeakIncident>> {
        return dao.observeIncidentsByDevice(deviceId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getIncidents(deviceId: String): List<LeakIncident> {
        return dao.getIncidentsByDevice(deviceId).map { it.toDomain() }
    }

    override suspend fun saveIncident(incident: LeakIncident): Long {
        if (incident.eventId <= 0) return -1L
        return dao.insertIncident(incident.toEntity())
    }

    override suspend fun saveIncidents(incidents: List<LeakIncident>): IncidentSaveResult {
        if (incidents.isEmpty()) {
            return IncidentSaveResult(
                totalReceived = 0,
                newInsertedCount = 0,
                existingIgnoredCount = 0
            )
        }

        val entities = incidents.map { it.toEntity() }
        val rowIds = dao.insertIncidents(entities)

        val newInserted = rowIds.count { it > 0 }
        val ignored = rowIds.count { it == -1L }

        return IncidentSaveResult(
            totalReceived = incidents.size,
            newInsertedCount = newInserted,
            existingIgnoredCount = ignored
        )
    }

    override suspend fun getIncidentCount(deviceId: String): Int {
        return dao.getIncidentCount(deviceId)
    }

    override suspend fun getTotalDurationSeconds(deviceId: String): Long {
        return dao.getTotalDurationSeconds(deviceId)
    }

    override suspend fun getLongestIncident(deviceId: String): LeakIncident? {
        return dao.getLongestIncident(deviceId)?.toDomain()
    }
}
