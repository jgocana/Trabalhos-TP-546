package br.inatel.mtel.leakguardiot.presentation.history

import br.inatel.mtel.leakguardiot.domain.model.LeakIncident

data class HistoryUiState(
    val incidents: List<LeakIncident> = emptyList(),
    val totalCount: Int = 0,
    val totalDurationSeconds: Long = 0L,
    val isLoading: Boolean = true
)
