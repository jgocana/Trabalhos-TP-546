package br.inatel.mtel.leakguardiot.data.local.mapper

import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident

fun LeakEventEntity.toDomain(): LeakIncident {
    val sanitizedStart = startedAtUnix?.takeIf { it > 0 }
    val sanitizedEnd = endedAtUnix?.takeIf { it > 0 }
    val validEnd = if (sanitizedStart != null && sanitizedEnd != null && sanitizedEnd < sanitizedStart) {
        null
    } else {
        sanitizedEnd
    }

    return LeakIncident(
        deviceId = deviceId,
        eventId = eventId,
        startedAtUnix = sanitizedStart,
        endedAtUnix = validEnd,
        durationSeconds = durationSeconds.coerceAtLeast(0L),
        receivedAtMillis = receivedAtMillis
    )
}

fun LeakIncident.toEntity(localId: Long = 0): LeakEventEntity {
    val sanitizedStart = startedAtUnix?.takeIf { it > 0 }
    val sanitizedEnd = endedAtUnix?.takeIf { it > 0 }
    val validEnd = if (sanitizedStart != null && sanitizedEnd != null && sanitizedEnd < sanitizedStart) {
        null
    } else {
        sanitizedEnd
    }

    return LeakEventEntity(
        localId = localId,
        deviceId = deviceId,
        eventId = eventId,
        startedAtUnix = sanitizedStart,
        endedAtUnix = validEnd,
        durationSeconds = durationSeconds.coerceAtLeast(0L),
        receivedAtMillis = receivedAtMillis
    )
}
