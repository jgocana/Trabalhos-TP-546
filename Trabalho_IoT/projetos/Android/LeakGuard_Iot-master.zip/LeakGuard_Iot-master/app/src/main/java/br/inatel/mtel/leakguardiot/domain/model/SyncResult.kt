package br.inatel.mtel.leakguardiot.domain.model

sealed interface SyncResult {
    data object Idle : SyncResult
    data class Syncing(val isManual: Boolean = false) : SyncResult
    data class Success(
        val totalReceived: Int,
        val newInsertedCount: Int,
        val existingIgnoredCount: Int,
        val timestampMillis: Long = System.currentTimeMillis(),
        val isManual: Boolean = false
    ) : SyncResult
    data class Error(
        val message: String,
        val isManual: Boolean = false
    ) : SyncResult
}
