package br.inatel.mtel.leakguardiot.data.dto

import android.os.SystemClock
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LeakGuardStateDto(
    @SerialName("water_detected") val waterDetected: Boolean = false,
    @SerialName("buzzer") val buzzer: Boolean = false,
    @SerialName("muted") val muted: Boolean = false,
    @SerialName("leak_count") val leakCount: Long? = null,
    @SerialName("current_leak_seconds") val currentLeakSeconds: Long? = null,
    @SerialName("total_leak_seconds") val totalLeakSeconds: Long? = null,
    @SerialName("updated_at_unix") val updatedAtUnix: Long? = null
) {
    fun toDomain(
        timestamp: Long = System.currentTimeMillis(),
        isRetained: Boolean = false,
        receivedAtMonotonic: Long = SystemClock.elapsedRealtime()
    ): LeakGuardState {
        return LeakGuardState(
            waterDetected = waterDetected,
            buzzerActive = buzzer,
            muted = muted,
            receivedAt = timestamp,
            leakCount = leakCount?.takeIf { it >= 0 },
            currentLeakSeconds = currentLeakSeconds?.takeIf { it >= 0 },
            totalLeakSeconds = totalLeakSeconds?.takeIf { it >= 0 },
            updatedAtUnix = updatedAtUnix?.takeIf { it > 0 },
            isRetained = isRetained,
            receivedAtMonotonic = receivedAtMonotonic
        )
    }
}
