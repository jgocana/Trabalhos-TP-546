package br.inatel.mtel.leakguardiot.domain.usecase

import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository

class GetDeviceStatusUseCase(
    private val repository: LeakGuardRepository
) {
    suspend operator fun invoke(): Result<Unit> {
        return repository.requestStatus()
    }
}
