package br.inatel.mtel.leakguardiot.domain.model

enum class EventType {
    WATER_DETECTED,
    WATER_CLEARED,
    ALARM_SILENCED,
    ALARM_UNMUTED,
    CONNECTION_LOST,
    CONNECTION_RESTORED,
    ESP32_CONNECTED,
    ESP32_DISCONNECTED,
    ESP32_SIGNAL_LOST,
    ESP32_SIGNAL_RESTORED
}

data class RecentEvent(
    val id: String,
    val type: EventType,
    val timestamp: Long,
    val description: String
)
