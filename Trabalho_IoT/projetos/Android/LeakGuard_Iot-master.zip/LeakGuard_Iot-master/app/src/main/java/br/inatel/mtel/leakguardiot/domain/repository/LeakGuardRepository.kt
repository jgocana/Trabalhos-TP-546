package br.inatel.mtel.leakguardiot.domain.repository

import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface LeakGuardRepository {
    val connectionState: StateFlow<ConnectionState>
    val leakGuardState: StateFlow<LeakGuardState?>
    val esp32LwtStatus: StateFlow<Esp32ConnectionStatus?>
    val incomingMessages: SharedFlow<MqttMessage>
    val subscriptionsConfirmed: StateFlow<Boolean>

    suspend fun connect()
    suspend fun disconnect()
    suspend fun silenceAlarm(): Result<Unit>
    suspend fun unmuteAlarm(): Result<Unit>
    suspend fun requestStatus(): Result<Unit>
    suspend fun requestHistory(): Result<Unit>
}
