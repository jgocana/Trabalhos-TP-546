package br.inatel.mtel.leakguardiot.data.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Esp32EventDto(
    @SerialName("type") val type: String = "",
    @SerialName("id") val id: Long = 0,
    @SerialName("timestamp_unix") val timestampUnix: Long? = null,
    @SerialName("duration_seconds") val durationSeconds: Long? = null
)
