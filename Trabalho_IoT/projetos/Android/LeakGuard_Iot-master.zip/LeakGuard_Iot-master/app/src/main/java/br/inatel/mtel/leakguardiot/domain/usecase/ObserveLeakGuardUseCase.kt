package br.inatel.mtel.leakguardiot.domain.usecase

import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import kotlinx.coroutines.flow.StateFlow

class ObserveLeakGuardUseCase(
    private val repository: LeakGuardRepository
) {
    val connectionState: StateFlow<ConnectionState> = repository.connectionState
    val leakGuardState: StateFlow<LeakGuardState?> = repository.leakGuardState
    val esp32LwtStatus: StateFlow<Esp32ConnectionStatus?> = repository.esp32LwtStatus
}
