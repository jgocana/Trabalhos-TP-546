package br.inatel.mtel.leakguardiot

import android.app.Application
import br.inatel.mtel.leakguardiot.di.AppContainer

class LeakGuardApplication : Application() {
    lateinit var appContainer: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        appContainer = AppContainer(this.applicationContext)
    }
}
