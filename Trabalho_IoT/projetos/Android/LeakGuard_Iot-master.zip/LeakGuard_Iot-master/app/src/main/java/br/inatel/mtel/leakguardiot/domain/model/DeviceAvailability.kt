package br.inatel.mtel.leakguardiot.domain.model

enum class DeviceAvailability {
    ONLINE,
    OFFLINE,
    SEM_SINAL,
    DESCONHECIDO
}
