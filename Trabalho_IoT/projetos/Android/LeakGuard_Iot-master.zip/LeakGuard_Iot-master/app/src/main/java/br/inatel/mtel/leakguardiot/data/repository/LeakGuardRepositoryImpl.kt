package br.inatel.mtel.leakguardiot.data.repository

import br.inatel.mtel.leakguardiot.data.dto.LeakGuardStateDto
import br.inatel.mtel.leakguardiot.data.mqtt.MqttClientManager
import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import kotlin.coroutines.resume

class LeakGuardRepositoryImpl(
    private val mqttClientManager: MqttClientManager,
    private val json: Json = Json { ignoreUnknownKeys = true }
) : LeakGuardRepository {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override val connectionState: StateFlow<ConnectionState> = mqttClientManager.connectionState
    override val subscriptionsConfirmed: StateFlow<Boolean> = mqttClientManager.subscriptionsConfirmed
    override val incomingMessages: SharedFlow<MqttMessage> = mqttClientManager.incomingMessages

    private val _leakGuardState = MutableStateFlow<LeakGuardState?>(null)
    override val leakGuardState: StateFlow<LeakGuardState?> = _leakGuardState.asStateFlow()

    private val _esp32LwtStatus = MutableStateFlow<Esp32ConnectionStatus?>(null)
    override val esp32LwtStatus: StateFlow<Esp32ConnectionStatus?> = _esp32LwtStatus.asStateFlow()

    init {
        scope.launch {
            mqttClientManager.incomingMessages.collect { message ->
                when (message.topic) {
                    MqttConfig.STATE_TOPIC -> {
                        try {
                            val dto = json.decodeFromString<LeakGuardStateDto>(message.payload)
                            _leakGuardState.value = dto.toDomain(
                                timestamp = message.receivedAtMillis,
                                isRetained = message.isRetained,
                                receivedAtMonotonic = message.receivedAtMonotonic
                            )
                        } catch (e: Exception) {
                            // Ignore malformed JSON payloads gracefully without crashing
                        }
                    }
                    MqttConfig.CONNECTION_TOPIC -> {
                        val payload = message.payload.trim().lowercase()
                        if (payload == "online") {
                            _esp32LwtStatus.value = Esp32ConnectionStatus(
                                isOnline = true,
                                isRetained = message.isRetained,
                                receivedAtMillis = message.receivedAtMillis,
                                receivedAtMonotonic = message.receivedAtMonotonic
                            )
                        } else if (payload == "offline") {
                            _esp32LwtStatus.value = Esp32ConnectionStatus(
                                isOnline = false,
                                isRetained = message.isRetained,
                                receivedAtMillis = message.receivedAtMillis,
                                receivedAtMonotonic = message.receivedAtMonotonic
                            )
                        }
                    }
                    MqttConfig.EVENT_TOPIC -> {
                        // Prepared for event topic processing in future stages
                    }
                    MqttConfig.HISTORY_TOPIC -> {
                        // Prepared for history topic processing in future stages
                    }
                }
            }
        }
    }

    override suspend fun connect() {
        mqttClientManager.connect()
    }

    override suspend fun disconnect() {
        mqttClientManager.disconnect()
    }

    override suspend fun silenceAlarm(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            mqttClientManager.publishCommand(MqttConfig.CMD_SILENCE) { result ->
                if (continuation.isActive) {
                    continuation.resume(result)
                }
            }
        }
    }

    override suspend fun unmuteAlarm(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            mqttClientManager.publishCommand(MqttConfig.CMD_UNMUTE) { result ->
                if (continuation.isActive) {
                    continuation.resume(result)
                }
            }
        }
    }

    override suspend fun requestStatus(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            mqttClientManager.publishCommand(MqttConfig.CMD_GET_STATUS) { result ->
                if (continuation.isActive) {
                    continuation.resume(result)
                }
            }
        }
    }

    override suspend fun requestHistory(): Result<Unit> {
        return suspendCancellableCoroutine { continuation ->
            mqttClientManager.publishCommand(MqttConfig.CMD_GET_HISTORY) { result ->
                if (continuation.isActive) {
                    continuation.resume(result)
                }
            }
        }
    }
}
