package br.inatel.mtel.leakguardiot.di

import android.content.Context
import br.inatel.mtel.leakguardiot.data.local.LeakGuardDatabase
import br.inatel.mtel.leakguardiot.data.local.dao.LeakEventDao
import br.inatel.mtel.leakguardiot.data.mqtt.MqttClientManager
import br.inatel.mtel.leakguardiot.data.repository.LeakHistoryRepositoryImpl
import br.inatel.mtel.leakguardiot.data.repository.LeakGuardRepositoryImpl
import br.inatel.mtel.leakguardiot.data.sync.LeakHistorySyncCoordinator
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceHistoryUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceStatusUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.ObserveLeakGuardUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.SilenceAlarmUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.UnmuteAlarmUseCase

class AppContainer(
    private val context: Context
) {
    val database: LeakGuardDatabase by lazy {
        LeakGuardDatabase.getInstance(context)
    }

    val leakEventDao: LeakEventDao by lazy {
        database.leakEventDao()
    }

    val leakHistoryRepository: LeakHistoryRepository by lazy {
        LeakHistoryRepositoryImpl(leakEventDao)
    }

    val mqttClientManager: MqttClientManager by lazy {
        MqttClientManager()
    }

    val leakGuardRepository: LeakGuardRepository by lazy {
        LeakGuardRepositoryImpl(mqttClientManager)
    }

    val leakHistorySyncCoordinator: LeakHistorySyncCoordinator by lazy {
        LeakHistorySyncCoordinator(
            leakGuardRepository = leakGuardRepository,
            leakHistoryRepository = leakHistoryRepository
        )
    }

    val observeLeakGuardUseCase: ObserveLeakGuardUseCase by lazy {
        ObserveLeakGuardUseCase(leakGuardRepository)
    }

    val silenceAlarmUseCase: SilenceAlarmUseCase by lazy {
        SilenceAlarmUseCase(leakGuardRepository)
    }

    val unmuteAlarmUseCase: UnmuteAlarmUseCase by lazy {
        UnmuteAlarmUseCase(leakGuardRepository)
    }

    val getDeviceStatusUseCase: GetDeviceStatusUseCase by lazy {
        GetDeviceStatusUseCase(leakGuardRepository)
    }

    val getDeviceHistoryUseCase: GetDeviceHistoryUseCase by lazy {
        GetDeviceHistoryUseCase(leakGuardRepository)
    }
}
