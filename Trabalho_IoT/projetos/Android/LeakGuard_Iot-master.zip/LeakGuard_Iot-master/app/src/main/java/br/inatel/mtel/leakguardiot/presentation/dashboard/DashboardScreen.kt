package br.inatel.mtel.leakguardiot.presentation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import br.inatel.mtel.leakguardiot.presentation.components.BuzzerAlarmCard
import br.inatel.mtel.leakguardiot.presentation.components.CommandButtons
import br.inatel.mtel.leakguardiot.presentation.components.ConnectionHeader
import br.inatel.mtel.leakguardiot.presentation.components.DeviceActionsSection
import br.inatel.mtel.leakguardiot.presentation.components.DeviceStatisticsSection
import br.inatel.mtel.leakguardiot.presentation.components.RecentEventsCard
import br.inatel.mtel.leakguardiot.presentation.components.StatusMainCard
import br.inatel.mtel.leakguardiot.presentation.components.WaterSensorCard
import br.inatel.mtel.leakguardiot.presentation.utils.TimeFormatUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.errorMessage) {
        val errorMsg = uiState.errorMessage
        if (!errorMsg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(errorMsg)
            viewModel.clearErrorMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with title, broker status, and ESP32 availability status
            ConnectionHeader(
                connectionState = uiState.connectionState,
                deviceAvailability = uiState.deviceAvailability
            )

            // Main Status Banner (Safe / Leak / Disconnected)
            StatusMainCard(
                waterDetected = uiState.waterDetected,
                deviceAvailability = uiState.deviceAvailability
            )

            // Sensor & Alarm Cards side-by-side
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                WaterSensorCard(
                    waterDetected = uiState.waterDetected,
                    deviceAvailability = uiState.deviceAvailability,
                    modifier = Modifier.weight(1f)
                )

                BuzzerAlarmCard(
                    buzzerActive = uiState.buzzerActive,
                    muted = uiState.muted,
                    deviceAvailability = uiState.deviceAvailability,
                    modifier = Modifier.weight(1f)
                )
            }

            // Command Control Buttons (SILENCE / UNMUTE)
            CommandButtons(
                isDeviceOnline = uiState.isDeviceOnline,
                isCommandPending = uiState.isCommandPending,
                pendingCommandName = uiState.pendingCommandName,
                onSilenceClick = { viewModel.silenceAlarm() },
                onUnmuteClick = { viewModel.unmuteAlarm() }
            )

            // Device Actions Section (GET_STATUS / GET_HISTORY)
            DeviceActionsSection(
                isDeviceOnline = uiState.isDeviceOnline,
                isStatusRequestPending = uiState.isStatusRequestPending,
                isHistoryRequestPending = uiState.isHistoryRequestPending,
                historyResponseMessage = uiState.historyResponseMessage,
                onRefreshStatusClick = { viewModel.refreshStatus() },
                onRequestHistoryClick = { viewModel.requestHistory() }
            )

            // Device Statistics Section
            DeviceStatisticsSection(
                leakCount = uiState.leakCount,
                currentLeakSeconds = uiState.currentLeakSeconds,
                totalLeakSeconds = uiState.totalLeakSeconds,
                waterDetected = uiState.waterDetected,
                deviceAvailability = uiState.deviceAvailability
            )

            // Timestamps: Device Reported Time & Local Reception Time
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val deviceTimestampFormatted = TimeFormatUtils.formatDeviceTimestamp(uiState.updatedAtUnix)
                Text(
                    text = deviceTimestampFormatted,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )

                val localReceptionFormatted = uiState.lastUpdatedTimestamp?.let {
                    SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(it))
                } ?: "Sem dados"

                Text(
                    text = "Última recepção local: $localReceptionFormatted",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center
                )
            }

            // Recent Events History Card
            RecentEventsCard(
                events = uiState.events
            )

            // Academic & Security Disclaimer Notice
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Nota de Segurança Academic/IoT",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Conexão demonstrativa MQTT TCP (Porta 1883) via broker público EMQX. Em ambiente comercial, utilize TLS 1.3, autenticação de usuário e controle de acesso.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
