package br.inatel.mtel.leakguardiot.presentation.statistics

data class DayLeakCount(
    val dayLabel: String,
    val count: Int
)

data class RecentLeakBar(
    val eventId: Long,
    val durationSeconds: Long,
    val formattedDuration: String,
    val ratio: Float
)

data class StatisticsUiState(
    val totalCount: Int = 0,
    val totalDurationSeconds: Long = 0L,
    val averageDurationSeconds: Long = 0L,
    val longestDurationSeconds: Long = 0L,
    val last7DaysCounts: List<DayLeakCount> = emptyList(),
    val last5LeakBars: List<RecentLeakBar> = emptyList(),
    val isLoading: Boolean = true
)
