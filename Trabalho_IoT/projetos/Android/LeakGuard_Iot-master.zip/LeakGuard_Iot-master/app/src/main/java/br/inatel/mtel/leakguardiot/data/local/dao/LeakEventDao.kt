package br.inatel.mtel.leakguardiot.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LeakEventDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIncident(entity: LeakEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIncidents(entities: List<LeakEventEntity>): List<Long>

    @Query("SELECT * FROM leak_events WHERE deviceId = :deviceId ORDER BY CASE WHEN startedAtUnix IS NULL THEN 0 ELSE 1 END DESC, startedAtUnix DESC, eventId DESC")
    suspend fun getIncidentsByDevice(deviceId: String): List<LeakEventEntity>

    @Query("SELECT * FROM leak_events WHERE deviceId = :deviceId ORDER BY CASE WHEN startedAtUnix IS NULL THEN 0 ELSE 1 END DESC, startedAtUnix DESC, eventId DESC")
    fun observeIncidentsByDevice(deviceId: String): Flow<List<LeakEventEntity>>

    @Query("SELECT COUNT(*) FROM leak_events WHERE deviceId = :deviceId")
    suspend fun getIncidentCount(deviceId: String): Int

    @Query("SELECT COALESCE(SUM(durationSeconds), 0) FROM leak_events WHERE deviceId = :deviceId")
    suspend fun getTotalDurationSeconds(deviceId: String): Long

    @Query("SELECT * FROM leak_events WHERE deviceId = :deviceId ORDER BY durationSeconds DESC LIMIT 1")
    suspend fun getLongestIncident(deviceId: String): LeakEventEntity?

    @Query("SELECT * FROM leak_events WHERE deviceId = :deviceId AND eventId = :eventId LIMIT 1")
    suspend fun getIncidentByDeviceAndEventId(deviceId: String, eventId: Long): LeakEventEntity?
}
