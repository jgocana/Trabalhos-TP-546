package br.inatel.mtel.leakguardiot.domain.model

data class LeakIncident(
    val deviceId: String,
    val eventId: Long,
    val startedAtUnix: Long? = null,
    val endedAtUnix: Long? = null,
    val durationSeconds: Long = 0L,
    val receivedAtMillis: Long = System.currentTimeMillis()
)
