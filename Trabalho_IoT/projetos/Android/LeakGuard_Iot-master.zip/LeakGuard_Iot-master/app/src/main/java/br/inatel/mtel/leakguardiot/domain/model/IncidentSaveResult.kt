package br.inatel.mtel.leakguardiot.domain.model

data class IncidentSaveResult(
    val totalReceived: Int,
    val newInsertedCount: Int,
    val existingIgnoredCount: Int
)
