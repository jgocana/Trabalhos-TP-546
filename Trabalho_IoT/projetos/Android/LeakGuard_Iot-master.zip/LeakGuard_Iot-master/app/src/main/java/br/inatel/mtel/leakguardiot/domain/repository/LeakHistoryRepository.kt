package br.inatel.mtel.leakguardiot.domain.repository

import br.inatel.mtel.leakguardiot.domain.model.IncidentSaveResult
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import kotlinx.coroutines.flow.Flow

interface LeakHistoryRepository {
    fun observeIncidents(deviceId: String): Flow<List<LeakIncident>>
    suspend fun getIncidents(deviceId: String): List<LeakIncident>
    suspend fun saveIncident(incident: LeakIncident): Long
    suspend fun saveIncidents(incidents: List<LeakIncident>): IncidentSaveResult
    suspend fun getIncidentCount(deviceId: String): Int
    suspend fun getTotalDurationSeconds(deviceId: String): Long
    suspend fun getLongestIncident(deviceId: String): LeakIncident?
}
