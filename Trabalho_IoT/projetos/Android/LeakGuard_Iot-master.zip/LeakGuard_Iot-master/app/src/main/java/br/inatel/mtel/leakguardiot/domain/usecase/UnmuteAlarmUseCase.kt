package br.inatel.mtel.leakguardiot.domain.usecase

import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository

class UnmuteAlarmUseCase(
    private val repository: LeakGuardRepository
) {
    suspend operator fun invoke(): Result<Unit> {
        return repository.unmuteAlarm()
    }
}
