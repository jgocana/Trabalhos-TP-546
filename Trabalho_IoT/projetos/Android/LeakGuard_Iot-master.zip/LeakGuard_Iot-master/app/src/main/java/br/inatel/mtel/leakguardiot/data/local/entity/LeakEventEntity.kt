package br.inatel.mtel.leakguardiot.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "leak_events",
    indices = [
        Index(value = ["deviceId", "eventId"], unique = true)
    ]
)
data class LeakEventEntity(
    @PrimaryKey(autoGenerate = true)
    val localId: Long = 0,
    val deviceId: String,
    val eventId: Long,
    val startedAtUnix: Long?,
    val endedAtUnix: Long?,
    val durationSeconds: Long,
    val receivedAtMillis: Long = System.currentTimeMillis()
)
