package br.inatel.mtel.leakguardiot.presentation.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability
import br.inatel.mtel.leakguardiot.presentation.utils.TimeFormatUtils

@Composable
fun DeviceStatisticsSection(
    leakCount: Long?,
    currentLeakSeconds: Long?,
    totalLeakSeconds: Long?,
    waterDetected: Boolean?,
    deviceAvailability: DeviceAvailability,
    modifier: Modifier = Modifier
) {
    val isOnline = deviceAvailability == DeviceAvailability.ONLINE

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Analytics,
                contentDescription = null,
                modifier = Modifier.size(22.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Estatísticas do dispositivo",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Card 1: Total de fugas
        StatCard(
            title = "Vazamentos detectados",
            value = leakCount?.toString() ?: "--",
            subtitle = if (!isOnline && leakCount != null) "Total do ESP32 (dados desatualizados)" else "Total registrado pelo ESP32",
            icon = Icons.Default.Analytics,
            valueColor = MaterialTheme.colorScheme.primary
        )

        // Card 2: Fuga actual
        val (currentLeakValue, currentLeakSubtitle, currentLeakColor) = when {
            waterDetected == null -> Triple("Sem informação", null, MaterialTheme.colorScheme.onSurfaceVariant)
            waterDetected == false -> Triple("Nenhum vazamento ativo", null, MaterialTheme.colorScheme.onSurface)
            currentLeakSeconds == null -> Triple("Duração indisponível", if (!isOnline) "Dados desatualizados" else null, Color(0xFFE65100))
            isOnline -> Triple(
                TimeFormatUtils.formatCurrentLeakDuration(currentLeakSeconds, isLeakActive = true),
                "Vazamento em andamento",
                Color(0xFFC62828)
            )
            else -> Triple(
                TimeFormatUtils.formatCurrentLeakDuration(currentLeakSeconds, isLeakActive = true),
                "Dados desatualizados",
                Color(0xFFE65100)
            )
        }

        StatCard(
            title = "Duração do vazamento atual",
            value = currentLeakValue,
            subtitle = currentLeakSubtitle,
            icon = Icons.Default.Timer,
            valueColor = currentLeakColor
        )

        // Card 3: Tiempo acumulado
        val totalLeakText = TimeFormatUtils.formatTotalLeakTime(totalLeakSeconds)
        StatCard(
            title = "Tempo total de vazamentos",
            value = totalLeakText,
            subtitle = if (!isOnline && totalLeakSeconds != null) "Tempo acumulado (dados desatualizados)" else "Tempo acumulado registrado pelo ESP32",
            icon = Icons.Default.Schedule,
            valueColor = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String?,
    icon: ImageVector,
    valueColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                modifier = Modifier.size(28.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = valueColor
                )
                if (!subtitle.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}
