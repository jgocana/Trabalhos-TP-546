package br.inatel.mtel.leakguardiot.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability

@Composable
fun ConnectionHeader(
    connectionState: ConnectionState,
    deviceAvailability: DeviceAvailability,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LeakGuard",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Monitoramento inteligente de vazamentos",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Broker Connection Status Badge
                val (brokerLabel, brokerColor) = when (connectionState) {
                    is ConnectionState.Connected -> "MQTT conectado" to Color(0xFF2E7D32)
                    is ConnectionState.Connecting -> "MQTT conectando" to Color(0xFFF57F17)
                    is ConnectionState.Reconnecting -> "MQTT reconectando" to Color(0xFFE65100)
                    is ConnectionState.Disconnected -> "MQTT desconectado" to Color(0xFF757575)
                    is ConnectionState.Error -> "Erro de conexão" to Color(0xFFC62828)
                }

                StatusBadge(
                    label = brokerLabel,
                    color = brokerColor
                )

                // ESP32 Availability Status Badge
                val (espLabel, espColor) = when (deviceAvailability) {
                    DeviceAvailability.ONLINE -> "ESP32 online" to Color(0xFF1B5E20)
                    DeviceAvailability.OFFLINE -> "ESP32 offline" to Color(0xFFC62828)
                    DeviceAvailability.SEM_SINAL -> "ESP32 sem sinal" to Color(0xFFE65100)
                    DeviceAvailability.DESCONHECIDO -> "Estado desconhecido" to Color(0xFF616161)
                }

                StatusBadge(
                    label = espLabel,
                    color = espColor
                )
            }
        }
    }
}

@Composable
private fun StatusBadge(
    label: String,
    color: Color
) {
    Surface(
        color = color.copy(alpha = 0.15f),
        contentColor = color,
        shape = RoundedCornerShape(50)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color = color, shape = CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = color
            )
        }
    }
}
