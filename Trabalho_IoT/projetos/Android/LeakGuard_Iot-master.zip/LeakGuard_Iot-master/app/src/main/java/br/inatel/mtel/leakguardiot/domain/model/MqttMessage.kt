package br.inatel.mtel.leakguardiot.domain.model

import android.os.SystemClock

data class MqttMessage(
    val topic: String,
    val payload: String,
    val isRetained: Boolean = false,
    val receivedAtMillis: Long = System.currentTimeMillis(),
    val receivedAtMonotonic: Long = SystemClock.elapsedRealtime()
)
