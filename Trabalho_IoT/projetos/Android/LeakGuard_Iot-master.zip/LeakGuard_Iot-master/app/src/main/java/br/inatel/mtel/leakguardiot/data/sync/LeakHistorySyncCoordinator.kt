package br.inatel.mtel.leakguardiot.data.sync

import android.os.SystemClock
import br.inatel.mtel.leakguardiot.data.dto.Esp32HistoryDto
import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import br.inatel.mtel.leakguardiot.domain.model.SyncResult
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json

class LeakHistorySyncCoordinator(
    private val leakGuardRepository: LeakGuardRepository,
    private val leakHistoryRepository: LeakHistoryRepository,
    private val json: Json = Json { ignoreUnknownKeys = true },
    private val timeProviderMonotonic: () -> Long = { SystemClock.elapsedRealtime() },
    private val timeProviderWallClock: () -> Long = System::currentTimeMillis,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    private val _syncResultState = MutableStateFlow<SyncResult>(SyncResult.Idle)
    val syncResultState: StateFlow<SyncResult> = _syncResultState.asStateFlow()

    private val syncMutex = Mutex()
    private var hasAutoRequestedHistoryForSession = false
    private var manualRequestMonotonic: Long? = null
    private var manualTimeoutJob: Job? = null

    init {
        startObservingHistoryMessages()
        startObservingConnectionForAutoSync()
    }

    private fun startObservingHistoryMessages() {
        externalScope.launch {
            leakGuardRepository.incomingMessages.collect { message ->
                if (message.topic == MqttConfig.HISTORY_TOPIC) {
                    val reqTime = manualRequestMonotonic
                    val isManualResponse = reqTime != null && !message.isRetained && message.receivedAtMonotonic >= reqTime

                    if (isManualResponse) {
                        manualTimeoutJob?.cancel()
                        manualRequestMonotonic = null
                    }

                    processHistoryMessage(message, isManual = isManualResponse)
                }
            }
        }
    }

    private fun startObservingConnectionForAutoSync() {
        externalScope.launch {
            combine(
                leakGuardRepository.connectionState,
                leakGuardRepository.subscriptionsConfirmed
            ) { connState, isConfirmed ->
                (connState is ConnectionState.Connected) && isConfirmed
            }.collect { isReady ->
                if (isReady) {
                    if (!hasAutoRequestedHistoryForSession) {
                        hasAutoRequestedHistoryForSession = true
                        leakGuardRepository.requestHistory()
                    }
                } else {
                    hasAutoRequestedHistoryForSession = false
                }
            }
        }
    }

    suspend fun requestManualHistory(): Result<Unit> {
        val reqTime = timeProviderMonotonic()
        manualRequestMonotonic = reqTime
        _syncResultState.value = SyncResult.Syncing(isManual = true)

        val pubResult = leakGuardRepository.requestHistory()
        if (pubResult.isFailure) {
            manualRequestMonotonic = null
            _syncResultState.value = SyncResult.Error("Falha ao enviar comando GET_HISTORY", isManual = true)
            return pubResult
        }

        scheduleManualTimeout(reqTime)
        return Result.success(Unit)
    }

    private fun scheduleManualTimeout(requestTimeMonotonic: Long) {
        manualTimeoutJob?.cancel()
        manualTimeoutJob = externalScope.launch {
            delay(5000L)
            if (manualRequestMonotonic == requestTimeMonotonic) {
                manualRequestMonotonic = null
                _syncResultState.value = SyncResult.Error("Tempo limite esgotado ao aguardar histórico.", isManual = true)
            }
        }
    }

    suspend fun processHistoryMessage(message: MqttMessage, isManual: Boolean): SyncResult {
        return syncMutex.withLock {
            _syncResultState.value = SyncResult.Syncing(isManual = isManual)

            val historyDto = try {
                json.decodeFromString<Esp32HistoryDto>(message.payload)
            } catch (e: Exception) {
                val err = SyncResult.Error("JSON de histórico inválido", isManual = isManual)
                _syncResultState.value = err
                return@withLock err
            }

            if (!validateHistoryDto(historyDto)) {
                val err = SyncResult.Error("Payload de histórico inválido", isManual = isManual)
                _syncResultState.value = err
                return@withLock err
            }

            val validIncidents = historyDto.events.map { event ->
                val start = event.startUnix.takeIf { it > 0 }
                val end = event.endUnix.takeIf { it > 0 }
                val validEnd = if (start != null && end != null && end < start) null else end

                LeakIncident(
                    deviceId = MqttConfig.DEVICE_ID,
                    eventId = event.id,
                    startedAtUnix = start,
                    endedAtUnix = validEnd,
                    durationSeconds = event.durationSeconds,
                    receivedAtMillis = message.receivedAtMillis
                )
            }

            try {
                val saveResult = leakHistoryRepository.saveIncidents(validIncidents)
                val success = SyncResult.Success(
                    totalReceived = saveResult.totalReceived,
                    newInsertedCount = saveResult.newInsertedCount,
                    existingIgnoredCount = saveResult.existingIgnoredCount,
                    timestampMillis = timeProviderWallClock(),
                    isManual = isManual
                )
                _syncResultState.value = success
                success
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                val err = SyncResult.Error("Erro ao salvar histórico no banco de dados", isManual = isManual)
                _syncResultState.value = err
                err
            }
        }
    }

    private fun validateHistoryDto(dto: Esp32HistoryDto): Boolean {
        if (dto.count !in 0..8) return false
        if (dto.count != dto.events.size) return false
        if (dto.events.isEmpty()) return true

        val ids = dto.events.map { it.id }
        if (ids.toSet().size != dto.events.size) return false

        for (event in dto.events) {
            if (event.id <= 0) return false
            if (event.durationSeconds < 0) return false
            if (event.startUnix < 0 || event.endUnix < 0) return false
            if (event.startUnix > 0 && event.endUnix > 0 && event.endUnix < event.startUnix) return false
        }
        return true
    }

    fun resetSyncResult() {
        _syncResultState.value = SyncResult.Idle
    }
}
