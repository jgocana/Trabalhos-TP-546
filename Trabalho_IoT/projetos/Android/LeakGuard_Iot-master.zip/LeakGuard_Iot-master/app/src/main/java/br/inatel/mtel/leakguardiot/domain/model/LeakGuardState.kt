package br.inatel.mtel.leakguardiot.domain.model

import android.os.SystemClock

data class LeakGuardState(
    val waterDetected: Boolean,
    val buzzerActive: Boolean,
    val muted: Boolean,
    val receivedAt: Long,
    val leakCount: Long? = null,
    val currentLeakSeconds: Long? = null,
    val totalLeakSeconds: Long? = null,
    val updatedAtUnix: Long? = null,
    val isRetained: Boolean = false,
    val receivedAtMonotonic: Long = SystemClock.elapsedRealtime()
)
