package br.inatel.mtel.leakguardiot.presentation.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val leakHistoryRepository: LeakHistoryRepository,
    private val deviceId: String = MqttConfig.DEVICE_ID
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        observeHistoryData()
    }

    private fun observeHistoryData() {
        viewModelScope.launch {
            leakHistoryRepository.observeIncidents(deviceId).collect { incidentList ->
                val count = incidentList.size
                val totalSecs = incidentList.sumOf { it.durationSeconds }
                _uiState.update { currentState ->
                    currentState.copy(
                        incidents = incidentList,
                        totalCount = count,
                        totalDurationSeconds = totalSecs,
                        isLoading = false
                    )
                }
            }
        }
    }
}
