package br.inatel.mtel.leakguardiot.presentation.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability

@Composable
fun WaterSensorCard(
    waterDetected: Boolean?,
    deviceAvailability: DeviceAvailability,
    modifier: Modifier = Modifier
) {
    val isOnline = deviceAvailability == DeviceAvailability.ONLINE
    val (statusText, chipColor, textColor) = when {
        waterDetected == null -> Triple("Sem informação", Color(0xFFECEFF1), Color(0xFF607D8B))
        waterDetected && isOnline -> Triple("Molhado", Color(0xFFFFEBEE), Color(0xFFC62828))
        waterDetected && !isOnline -> Triple("Molhado (antigo)", Color(0xFFFFF3E0), Color(0xFFE65100))
        else -> Triple("Seco", Color(0xFFE8F5E9), Color(0xFF2E7D32))
    }

    InfoCard(
        title = "Sensor de água",
        statusText = statusText,
        icon = Icons.Default.WaterDrop,
        chipColor = chipColor,
        textColor = textColor,
        modifier = modifier
    )
}

@Composable
fun BuzzerAlarmCard(
    buzzerActive: Boolean?,
    muted: Boolean?,
    deviceAvailability: DeviceAvailability,
    modifier: Modifier = Modifier
) {
    val (statusText, chipColor, textColor, icon) = when {
        buzzerActive == null || muted == null -> Triple("Desconhecido", Color(0xFFECEFF1), Color(0xFF607D8B)).let { (a, b, c) -> Quadruple(a, b, c, Icons.AutoMirrored.Filled.VolumeOff) }
        muted -> Quadruple("Silenciado", Color(0xFFE3F2FD), Color(0xFF1565C0), Icons.AutoMirrored.Filled.VolumeOff)
        buzzerActive -> Quadruple("Ativo", Color(0xFFFFEBEE), Color(0xFFC62828), Icons.AutoMirrored.Filled.VolumeUp)
        else -> Quadruple("Desligado", Color(0xFFE8F5E9), Color(0xFF2E7D32), Icons.AutoMirrored.Filled.VolumeOff)
    }

    InfoCard(
        title = "Alarme sonoro",
        statusText = statusText,
        icon = icon,
        chipColor = chipColor,
        textColor = textColor,
        modifier = modifier
    )
}

@Composable
private fun InfoCard(
    title: String,
    statusText: String,
    icon: ImageVector,
    chipColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    modifier = Modifier.size(24.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = chipColor,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = statusText,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = textColor
                )
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
