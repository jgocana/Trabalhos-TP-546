package br.inatel.mtel.leakguardiot.presentation.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeFormatUtils {

    fun formatCurrentLeakDuration(seconds: Long?, isLeakActive: Boolean): String {
        if (!isLeakActive || seconds == null || seconds < 0) {
            return "Nenhum vazamento ativo"
        }
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60

        return if (hours > 0) {
            String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, secs)
        } else {
            String.format(Locale.getDefault(), "%02d:%02d", minutes, secs)
        }
    }

    fun formatTotalLeakTime(seconds: Long?): String {
        if (seconds == null || seconds < 0) return "Sem informação"
        if (seconds == 0L) return "0 s"

        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60

        return when {
            hours > 0 -> if (minutes > 0) "${hours} h ${minutes} min" else "${hours} h"
            minutes > 0 -> if (secs > 0) "${minutes} min ${secs} s" else "${minutes} min"
            else -> "${secs} s"
        }
    }

    fun formatDeviceTimestamp(unixSeconds: Long?): String {
        if (unixSeconds == null || unixSeconds <= 0) {
            return "Horário do dispositivo indisponível"
        }
        return try {
            val millis = unixSeconds * 1000L
            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(millis))
            "Última atualização do dispositivo: $dateStr"
        } catch (e: Exception) {
            "Horário do dispositivo indisponível"
        }
    }

    fun formatUnixTimestamp(unixSeconds: Long?): String {
        if (unixSeconds == null || unixSeconds <= 0) {
            return "Horário indisponível"
        }
        return try {
            val millis = unixSeconds * 1000L
            val sdf = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", Locale.getDefault())
            sdf.format(Date(millis))
        } catch (e: Exception) {
            "Horário indisponível"
        }
    }
}
