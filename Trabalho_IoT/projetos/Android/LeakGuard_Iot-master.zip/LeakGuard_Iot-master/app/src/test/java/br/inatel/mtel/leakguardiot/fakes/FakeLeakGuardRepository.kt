package br.inatel.mtel.leakguardiot.fakes

import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import br.inatel.mtel.leakguardiot.domain.repository.LeakGuardRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FakeLeakGuardRepository : LeakGuardRepository {

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _subscriptionsConfirmed = MutableStateFlow(false)
    override val subscriptionsConfirmed: StateFlow<Boolean> = _subscriptionsConfirmed.asStateFlow()

    private val _leakGuardState = MutableStateFlow<LeakGuardState?>(null)
    override val leakGuardState: StateFlow<LeakGuardState?> = _leakGuardState.asStateFlow()

    private val _esp32LwtStatus = MutableStateFlow<Esp32ConnectionStatus?>(null)
    override val esp32LwtStatus: StateFlow<Esp32ConnectionStatus?> = _esp32LwtStatus.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<MqttMessage>(replay = 1)
    override val incomingMessages: SharedFlow<MqttMessage> = _incomingMessages

    var silenceCalled = false
    var unmuteCalled = false
    var requestStatusCalled = false
    var requestHistoryCalled = false
    var shouldFailCommands = false

    override suspend fun connect() {
        _connectionState.value = ConnectionState.Connected
        _subscriptionsConfirmed.value = true
    }

    override suspend fun disconnect() {
        _subscriptionsConfirmed.value = false
        _connectionState.value = ConnectionState.Disconnected
    }

    override suspend fun silenceAlarm(): Result<Unit> {
        silenceCalled = true
        return if (shouldFailCommands) {
            Result.failure(RuntimeException("Falha de rede ao enviar SILENCE"))
        } else {
            Result.success(Unit)
        }
    }

    override suspend fun unmuteAlarm(): Result<Unit> {
        unmuteCalled = true
        return if (shouldFailCommands) {
            Result.failure(RuntimeException("Falha de rede ao enviar UNMUTE"))
        } else {
            Result.success(Unit)
        }
    }

    override suspend fun requestStatus(): Result<Unit> {
        requestStatusCalled = true
        return if (shouldFailCommands) {
            Result.failure(RuntimeException("Falha de rede ao enviar GET_STATUS"))
        } else {
            Result.success(Unit)
        }
    }

    override suspend fun requestHistory(): Result<Unit> {
        requestHistoryCalled = true
        return if (shouldFailCommands) {
            Result.failure(RuntimeException("Falha de rede ao enviar GET_HISTORY"))
        } else {
            Result.success(Unit)
        }
    }

    fun emitState(state: LeakGuardState) {
        _leakGuardState.value = state
    }

    fun emitConnectionState(state: ConnectionState) {
        _connectionState.value = state
    }

    fun emitSubscriptionsConfirmed(confirmed: Boolean) {
        _subscriptionsConfirmed.value = confirmed
    }

    fun emitEsp32LwtStatus(status: Esp32ConnectionStatus) {
        _esp32LwtStatus.value = status
    }

    suspend fun emitIncomingMessage(message: MqttMessage) {
        _incomingMessages.emit(message)
    }
}
