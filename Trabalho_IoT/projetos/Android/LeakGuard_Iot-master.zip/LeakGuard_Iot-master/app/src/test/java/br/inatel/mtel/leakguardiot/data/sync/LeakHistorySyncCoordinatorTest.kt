package br.inatel.mtel.leakguardiot.data.sync

import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import br.inatel.mtel.leakguardiot.domain.model.SyncResult
import br.inatel.mtel.leakguardiot.fakes.FakeLeakHistoryRepository
import br.inatel.mtel.leakguardiot.fakes.FakeLeakGuardRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LeakHistorySyncCoordinatorTest {

    private val testDispatcher = StandardTestDispatcher()
    private val testScope = TestScope(testDispatcher)

    private lateinit var fakeMqttRepo: FakeLeakGuardRepository
    private lateinit var fakeRoomRepo: FakeLeakHistoryRepository
    private lateinit var coordinator: LeakHistorySyncCoordinator

    private var simulatedMonotonicMs: Long = 100_000L

    private val oneEventJson = """
        {
          "count": 1,
          "events": [
            {
              "id": 1,
              "start_unix": 1794064500,
              "end_unix": 1794064530,
              "duration_seconds": 30
            }
          ]
        }
    """.trimIndent()

    private val eightEventsJson = """
        {
          "count": 8,
          "events": [
            {"id": 1, "start_unix": 1000, "end_unix": 1010, "duration_seconds": 10},
            {"id": 2, "start_unix": 1020, "end_unix": 1030, "duration_seconds": 10},
            {"id": 3, "start_unix": 1040, "end_unix": 1050, "duration_seconds": 10},
            {"id": 4, "start_unix": 1060, "end_unix": 1070, "duration_seconds": 10},
            {"id": 5, "start_unix": 1080, "end_unix": 1090, "duration_seconds": 10},
            {"id": 6, "start_unix": 1100, "end_unix": 1110, "duration_seconds": 10},
            {"id": 7, "start_unix": 1120, "end_unix": 1130, "duration_seconds": 10},
            {"id": 8, "start_unix": 1140, "end_unix": 1150, "duration_seconds": 10}
          ]
        }
    """.trimIndent()

    @Before
    fun setUp() {
        fakeMqttRepo = FakeLeakGuardRepository()
        fakeRoomRepo = FakeLeakHistoryRepository()
        simulatedMonotonicMs = 100_000L

        coordinator = LeakHistorySyncCoordinator(
            leakGuardRepository = fakeMqttRepo,
            leakHistoryRepository = fakeRoomRepo,
            timeProviderMonotonic = { simulatedMonotonicMs },
            externalScope = testScope
        )
    }

    @Test
    fun `test 1 - reception of history with one incident`() = runTest {
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = oneEventJson,
            isRetained = false,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Success)
        val success = result as SyncResult.Success
        assertEquals(1, success.totalReceived)
        assertEquals(1, success.newInsertedCount)
        assertEquals(0, success.existingIgnoredCount)
    }

    @Test
    fun `test 2 - reception of history with eight incidents`() = runTest {
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = eightEventsJson,
            isRetained = false,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Success)
        val success = result as SyncResult.Success
        assertEquals(8, success.totalReceived)
        assertEquals(8, success.newInsertedCount)
        assertEquals(0, success.existingIgnoredCount)
    }

    @Test
    fun `test 3 - valid empty history payload count 0`() = runTest {
        val emptyJson = "{\"count\": 0, \"events\": []}"
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = emptyJson,
            isRetained = false,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Success)
        val success = result as SyncResult.Success
        assertEquals(0, success.totalReceived)
        assertEquals(0, success.newInsertedCount)
    }

    @Test
    fun `test 4 & 5 - retained history message on subscribe is processed into Room`() = runTest {
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = oneEventJson,
            isRetained = true,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        fakeMqttRepo.emitIncomingMessage(msg)
        testScope.runCurrent()

        val state = coordinator.syncResultState.value
        assertTrue(state is SyncResult.Success)
        assertEquals(1, fakeRoomRepo.getIncidentCount(MqttConfig.DEVICE_ID))
    }

    @Test
    fun `test 6 & 9 - repeated reception of same history is idempotent and ignored by Room`() = runTest {
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = oneEventJson,
            isRetained = false,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        coordinator.processHistoryMessage(msg, isManual = false)
        val secondResult = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(secondResult is SyncResult.Success)
        val success = secondResult as SyncResult.Success
        assertEquals(1, success.totalReceived)
        assertEquals(0, success.newInsertedCount)
        assertEquals(1, success.existingIgnoredCount)
        assertEquals(1, fakeRoomRepo.getIncidentCount(MqttConfig.DEVICE_ID))
    }

    @Test
    fun `test 7 - partially overlapping history payload`() = runTest {
        val msg1 = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = eightEventsJson, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)
        coordinator.processHistoryMessage(msg1, isManual = false)
        assertEquals(8, fakeRoomRepo.getIncidentCount(MqttConfig.DEVICE_ID))

        val overlapJson = """
            {
              "count": 3,
              "events": [
                {"id": 7, "start_unix": 1120, "end_unix": 1130, "duration_seconds": 10},
                {"id": 8, "start_unix": 1140, "end_unix": 1150, "duration_seconds": 10},
                {"id": 9, "start_unix": 1160, "end_unix": 1170, "duration_seconds": 10}
              ]
            }
        """.trimIndent()
        val msg2 = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = overlapJson, isRetained = false, receivedAtMillis = 2000L, receivedAtMonotonic = simulatedMonotonicMs + 1000L)

        val result2 = coordinator.processHistoryMessage(msg2, isManual = false) as SyncResult.Success

        assertEquals(3, result2.totalReceived)
        assertEquals(1, result2.newInsertedCount) // Only event 9 is new
        assertEquals(2, result2.existingIgnoredCount) // Events 7 and 8 ignored
        assertEquals(9, fakeRoomRepo.getIncidentCount(MqttConfig.DEVICE_ID))
    }

    @Test
    fun `test 8 & 13 - auto GET_HISTORY requested on connect and reconnect`() = runTest {
        fakeMqttRepo.emitConnectionState(ConnectionState.Connected)
        fakeMqttRepo.emitSubscriptionsConfirmed(true)
        testScope.runCurrent()

        assertTrue(fakeMqttRepo.requestHistoryCalled)
        fakeMqttRepo.requestHistoryCalled = false

        // Reconnect
        fakeMqttRepo.emitConnectionState(ConnectionState.Disconnected)
        testScope.runCurrent()

        fakeMqttRepo.emitConnectionState(ConnectionState.Connected)
        fakeMqttRepo.emitSubscriptionsConfirmed(true)
        testScope.runCurrent()

        assertTrue(fakeMqttRepo.requestHistoryCalled)
    }

    @Test
    fun `test 10 - invalid JSON syntax is rejected`() = runTest {
        val msg = MqttMessage(
            topic = MqttConfig.HISTORY_TOPIC,
            payload = "{ invalid json }",
            isRetained = false,
            receivedAtMillis = 1000L,
            receivedAtMonotonic = simulatedMonotonicMs
        )

        val result = coordinator.processHistoryMessage(msg, isManual = true)

        assertTrue(result is SyncResult.Error)
        assertEquals("JSON de histórico inválido", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 11 - invalid event ID rejected`() = runTest {
        val jsonInvalidId = """
            {
              "count": 1,
              "events": [
                {"id": 0, "start_unix": 1000, "end_unix": 1010, "duration_seconds": 10}
              ]
            }
        """.trimIndent()
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = jsonInvalidId, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Error)
        assertEquals("Payload de histórico inválido", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 12 - negative duration rejected`() = runTest {
        val jsonNegativeDuration = """
            {
              "count": 1,
              "events": [
                {"id": 1, "start_unix": 1000, "end_unix": 1010, "duration_seconds": -5}
              ]
            }
        """.trimIndent()
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = jsonNegativeDuration, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Error)
        assertEquals("Payload de histórico inválido", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 13 - end date prior to start date rejected`() = runTest {
        val jsonEndBeforeStart = """
            {
              "count": 1,
              "events": [
                {"id": 1, "start_unix": 1000, "end_unix": 500, "duration_seconds": 10}
              ]
            }
        """.trimIndent()
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = jsonEndBeforeStart, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Error)
        assertEquals("Payload de histórico inválido", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 14 - inconsistent count vs events size rejected`() = runTest {
        val jsonInconsistentCount = """
            {
              "count": 5,
              "events": [
                {"id": 1, "start_unix": 1000, "end_unix": 1010, "duration_seconds": 10}
              ]
            }
        """.trimIndent()
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = jsonInconsistentCount, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Error)
        assertEquals("Payload de histórico inválido", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 15 - Room insertion exception returns Error result`() = runTest {
        fakeRoomRepo.shouldFailSave = true
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = oneEventJson, isRetained = false, receivedAtMillis = 1000L, receivedAtMonotonic = simulatedMonotonicMs)

        val result = coordinator.processHistoryMessage(msg, isManual = false)

        assertTrue(result is SyncResult.Error)
        assertEquals("Erro ao salvar histórico no banco de dados", (result as SyncResult.Error).message)
    }

    @Test
    fun `test 16 - manual request successful after persistence`() = runTest {
        fakeMqttRepo.emitConnectionState(ConnectionState.Connected)
        fakeMqttRepo.emitSubscriptionsConfirmed(true)
        testScope.runCurrent()

        val pubRes = coordinator.requestManualHistory()
        assertTrue(pubRes.isSuccess)
        testScope.runCurrent()

        assertTrue(coordinator.syncResultState.value is SyncResult.Syncing)

        // Incoming new history response
        simulatedMonotonicMs += 500L
        val msg = MqttMessage(topic = MqttConfig.HISTORY_TOPIC, payload = oneEventJson, isRetained = false, receivedAtMillis = 2000L, receivedAtMonotonic = simulatedMonotonicMs)
        fakeMqttRepo.emitIncomingMessage(msg)
        testScope.runCurrent()

        val state = coordinator.syncResultState.value
        assertTrue(state is SyncResult.Success)
        val success = state as SyncResult.Success
        assertTrue(success.isManual)
        assertEquals(1, success.newInsertedCount)
    }
}
