package br.inatel.mtel.leakguardiot

import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity
import br.inatel.mtel.leakguardiot.data.local.mapper.toDomain
import br.inatel.mtel.leakguardiot.data.local.mapper.toEntity
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import br.inatel.mtel.leakguardiot.fakes.FakeLeakHistoryRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LeakHistoryRepositoryTest {

    private lateinit var repository: FakeLeakHistoryRepository
    private val deviceId = "jgocana-yverdecia-iot-device01"

    @Before
    fun setUp() {
        repository = FakeLeakHistoryRepository()
    }

    @Test
    fun `test 1 - save single valid incident`() = runTest {
        val incident = LeakIncident(
            deviceId = deviceId,
            eventId = 3L,
            startedAtUnix = 1794064700L,
            endedAtUnix = 1794064745L,
            durationSeconds = 45L
        )

        val rowId = repository.saveIncident(incident)
        assertTrue(rowId > 0)

        val saved = repository.getIncidents(deviceId)
        assertEquals(1, saved.size)
        assertEquals(3L, saved[0].eventId)
        assertEquals(45L, saved[0].durationSeconds)
    }

    @Test
    fun `test 2 & 3 - save multiple incidents and prevent duplicates`() = runTest {
        val list = listOf(
            LeakIncident(deviceId = deviceId, eventId = 1L, startedAtUnix = 1000L, endedAtUnix = 1030L, durationSeconds = 30L),
            LeakIncident(deviceId = deviceId, eventId = 2L, startedAtUnix = 2000L, endedAtUnix = 2045L, durationSeconds = 45L),
            LeakIncident(deviceId = deviceId, eventId = 1L, startedAtUnix = 1000L, endedAtUnix = 1030L, durationSeconds = 30L) // Duplicate
        )

        val saveResult = repository.saveIncidents(list)
        assertEquals(3, saveResult.totalReceived)
        assertEquals(2, saveResult.newInsertedCount)
        assertEquals(1, saveResult.existingIgnoredCount)

        val count = repository.getIncidentCount(deviceId)
        assertEquals(2, count)
    }

    @Test
    fun `test 4 & 5 - query incidents by device in chronological order`() = runTest {
        repository.saveIncident(LeakIncident(deviceId = deviceId, eventId = 1L, startedAtUnix = 1000L, endedAtUnix = 1030L, durationSeconds = 30L))
        repository.saveIncident(LeakIncident(deviceId = deviceId, eventId = 2L, startedAtUnix = 2000L, endedAtUnix = 2045L, durationSeconds = 45L))
        repository.saveIncident(LeakIncident(deviceId = "other-device", eventId = 99L, startedAtUnix = 5000L, endedAtUnix = 5010L, durationSeconds = 10L))

        val incidents = repository.getIncidents(deviceId)
        assertEquals(2, incidents.size)
        // Ordered by startedAtUnix DESC
        assertEquals(2L, incidents[0].eventId)
        assertEquals(1L, incidents[1].eventId)
    }

    @Test
    fun `test 6 & 7 - incident count and total accumulated duration`() = runTest {
        repository.saveIncident(LeakIncident(deviceId = deviceId, eventId = 1L, startedAtUnix = 1000L, endedAtUnix = 1030L, durationSeconds = 30L))
        repository.saveIncident(LeakIncident(deviceId = deviceId, eventId = 2L, startedAtUnix = 2000L, endedAtUnix = 2045L, durationSeconds = 45L))

        val count = repository.getIncidentCount(deviceId)
        val totalSecs = repository.getTotalDurationSeconds(deviceId)

        assertEquals(2, count)
        assertEquals(75L, totalSecs)
    }

    @Test
    fun `test 8 - empty history returns zero count and empty list`() = runTest {
        val count = repository.getIncidentCount(deviceId)
        val list = repository.getIncidents(deviceId)
        val longest = repository.getLongestIncident(deviceId)

        assertEquals(0, count)
        assertTrue(list.isEmpty())
        assertNull(longest)
    }

    @Test
    fun `test 10 & 11 - sanitization converts unix 0 to null and negative duration to 0`() {
        val entity = LeakEventEntity(
            localId = 1L,
            deviceId = deviceId,
            eventId = 5L,
            startedAtUnix = 0L,
            endedAtUnix = -100L,
            durationSeconds = -30L
        )

        val domain = entity.toDomain()

        assertNull(domain.startedAtUnix)
        assertNull(domain.endedAtUnix)
        assertEquals(0L, domain.durationSeconds)

        val entityBack = domain.toEntity()
        assertNull(entityBack.startedAtUnix)
        assertNull(entityBack.endedAtUnix)
        assertEquals(0L, entityBack.durationSeconds)
    }
}
