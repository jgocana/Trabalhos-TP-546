package br.inatel.mtel.leakguardiot

import br.inatel.mtel.leakguardiot.data.dto.Esp32HistoryDto
import br.inatel.mtel.leakguardiot.data.dto.LeakGuardStateDto
import br.inatel.mtel.leakguardiot.presentation.utils.TimeFormatUtils
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JsonParsingTest {

    private val json = Json { ignoreUnknownKeys = true }

    @Test
    fun `parse complete JSON with statistics`() {
        val rawJson = """
            {
              "water_detected": true,
              "buzzer": false,
              "muted": true,
              "leak_count": 3,
              "current_leak_seconds": 25,
              "total_leak_seconds": 145,
              "updated_at_unix": 1794064800
            }
        """.trimIndent()

        val dto = json.decodeFromString<LeakGuardStateDto>(rawJson)
        val domain = dto.toDomain(timestamp = 1000L)

        assertTrue(domain.waterDetected)
        assertFalse(domain.buzzerActive)
        assertTrue(domain.muted)
        assertEquals(3L, domain.leakCount)
        assertEquals(25L, domain.currentLeakSeconds)
        assertEquals(145L, domain.totalLeakSeconds)
        assertEquals(1794064800L, domain.updatedAtUnix)
    }

    @Test
    fun `parse real ESP32 history JSON format`() {
        val rawJson = """
            {
              "count": 1,
              "events": [
                {
                  "id": 3,
                  "start_unix": 1794064700,
                  "end_unix": 1794064745,
                  "duration_seconds": 45
                }
              ]
            }
        """.trimIndent()

        val historyDto = json.decodeFromString<Esp32HistoryDto>(rawJson)

        assertEquals(1, historyDto.count)
        assertEquals(1, historyDto.events.size)
        assertEquals(3L, historyDto.events[0].id)
        assertEquals(1794064700L, historyDto.events[0].startUnix)
        assertEquals(1794064745L, historyDto.events[0].endUnix)
        assertEquals(45L, historyDto.events[0].durationSeconds)
    }

    @Test
    fun `parse JSON without new statistics leaves statistics as null`() {
        val rawJson = """
            {
              "water_detected": false,
              "buzzer": false,
              "muted": false
            }
        """.trimIndent()

        val dto = json.decodeFromString<LeakGuardStateDto>(rawJson)
        val domain = dto.toDomain(timestamp = 2000L)

        assertFalse(domain.waterDetected)
        assertNull(domain.leakCount)
        assertNull(domain.currentLeakSeconds)
        assertNull(domain.totalLeakSeconds)
        assertNull(domain.updatedAtUnix)
    }

    @Test
    fun `parse JSON with negative values sanitizes them to null`() {
        val rawJson = """
            {
              "water_detected": true,
              "buzzer": true,
              "muted": false,
              "leak_count": -5,
              "current_leak_seconds": -10,
              "total_leak_seconds": -100,
              "updated_at_unix": -1
            }
        """.trimIndent()

        val dto = json.decodeFromString<LeakGuardStateDto>(rawJson)
        val domain = dto.toDomain(timestamp = 3000L)

        assertNull(domain.leakCount)
        assertNull(domain.currentLeakSeconds)
        assertNull(domain.totalLeakSeconds)
        assertNull(domain.updatedAtUnix)
    }

    @Test(expected = Exception::class)
    fun `parse invalid JSON syntax throws exception`() {
        val rawJson = "{\"water_detected\": \"INVALID_BOOLEAN\", \"buzzer\": invalid}"
        json.decodeFromString<LeakGuardStateDto>(rawJson)
    }

    @Test
    fun `format current leak duration helper test`() {
        assertEquals("00:25", TimeFormatUtils.formatCurrentLeakDuration(25L, isLeakActive = true))
        assertEquals("01:12:30", TimeFormatUtils.formatCurrentLeakDuration(4350L, isLeakActive = true))
        assertEquals("Nenhum vazamento ativo", TimeFormatUtils.formatCurrentLeakDuration(25L, isLeakActive = false))
        assertEquals("Nenhum vazamento ativo", TimeFormatUtils.formatCurrentLeakDuration(null, isLeakActive = true))
    }

    @Test
    fun `format total leak time helper test`() {
        assertEquals("45 s", TimeFormatUtils.formatTotalLeakTime(45L))
        assertEquals("12 min 30 s", TimeFormatUtils.formatTotalLeakTime(750L))
        assertEquals("2 h 15 min", TimeFormatUtils.formatTotalLeakTime(8100L))
        assertEquals("Sem informação", TimeFormatUtils.formatTotalLeakTime(null))
        assertEquals("Sem informação", TimeFormatUtils.formatTotalLeakTime(-5L))
    }

    @Test
    fun `format device timestamp helper test`() {
        val formatted = TimeFormatUtils.formatDeviceTimestamp(1794064800L)
        assertTrue(formatted.startsWith("Última atualização do dispositivo:"))
        assertEquals("Horário do dispositivo indisponível", TimeFormatUtils.formatDeviceTimestamp(0L))
        assertEquals("Horário do dispositivo indisponível", TimeFormatUtils.formatDeviceTimestamp(null))
    }
}
