package br.inatel.mtel.leakguardiot.fakes

import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity
import br.inatel.mtel.leakguardiot.data.local.mapper.toDomain
import br.inatel.mtel.leakguardiot.data.local.mapper.toEntity
import br.inatel.mtel.leakguardiot.domain.model.IncidentSaveResult
import br.inatel.mtel.leakguardiot.domain.model.LeakIncident
import br.inatel.mtel.leakguardiot.domain.repository.LeakHistoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

class FakeLeakHistoryRepository : LeakHistoryRepository {

    private val storage = mutableListOf<LeakEventEntity>()
    private val flowStorage = MutableStateFlow<List<LeakEventEntity>>(emptyList())
    private var autoIncrementId = 1L

    var shouldFailSave = false

    override fun observeIncidents(deviceId: String): Flow<List<LeakIncident>> {
        return flowStorage.map { list ->
            list.filter { it.deviceId == deviceId }
                .map { it.toDomain() }
        }
    }

    override suspend fun getIncidents(deviceId: String): List<LeakIncident> {
        return storage.filter { it.deviceId == deviceId }
            .sortedWith(
                compareByDescending<LeakEventEntity> { it.startedAtUnix != null }
                    .thenByDescending { it.startedAtUnix ?: 0L }
                    .thenByDescending { it.eventId }
            )
            .map { it.toDomain() }
    }

    override suspend fun saveIncident(incident: LeakIncident): Long {
        if (shouldFailSave) throw RuntimeException("DB Save Exception")
        if (incident.eventId <= 0) return -1L

        val existing = storage.find { it.deviceId == incident.deviceId && it.eventId == incident.eventId }
        if (existing != null) {
            return -1L // IGNORE duplicate
        }

        val entity = incident.toEntity(localId = autoIncrementId++)
        storage.add(entity)
        flowStorage.value = storage.toList()
        return entity.localId
    }

    override suspend fun saveIncidents(incidents: List<LeakIncident>): IncidentSaveResult {
        if (shouldFailSave) throw RuntimeException("DB Save Exception")

        var inserted = 0
        var ignored = 0

        for (inc in incidents) {
            val res = saveIncident(inc)
            if (res > 0) {
                inserted++
            } else {
                ignored++
            }
        }
        return IncidentSaveResult(
            totalReceived = incidents.size,
            newInsertedCount = inserted,
            existingIgnoredCount = ignored
        )
    }

    override suspend fun getIncidentCount(deviceId: String): Int {
        return storage.count { it.deviceId == deviceId }
    }

    override suspend fun getTotalDurationSeconds(deviceId: String): Long {
        return storage.filter { it.deviceId == deviceId }.sumOf { it.durationSeconds }
    }

    override suspend fun getLongestIncident(deviceId: String): LeakIncident? {
        return storage.filter { it.deviceId == deviceId }
            .maxByOrNull { it.durationSeconds }
            ?.toDomain()
    }
}
