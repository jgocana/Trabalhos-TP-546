package br.inatel.mtel.leakguardiot

import br.inatel.mtel.leakguardiot.data.mqtt.MqttConfig
import br.inatel.mtel.leakguardiot.domain.model.ConnectionState
import br.inatel.mtel.leakguardiot.domain.model.DeviceAvailability
import br.inatel.mtel.leakguardiot.domain.model.Esp32ConnectionStatus
import br.inatel.mtel.leakguardiot.domain.model.LeakGuardState
import br.inatel.mtel.leakguardiot.domain.model.MqttMessage
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceHistoryUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.GetDeviceStatusUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.ObserveLeakGuardUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.SilenceAlarmUseCase
import br.inatel.mtel.leakguardiot.domain.usecase.UnmuteAlarmUseCase
import br.inatel.mtel.leakguardiot.fakes.FakeLeakGuardRepository
import br.inatel.mtel.leakguardiot.presentation.dashboard.DashboardViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var repository: FakeLeakGuardRepository
    private lateinit var viewModel: DashboardViewModel
    private var simulatedTimeMs: Long = 100_000L

    private val realHistoryJson = """
        {
          "count": 1,
          "events": [
            {
              "id": 3,
              "start_unix": 1794064700,
              "end_unix": 1794064745,
              "duration_seconds": 45
            }
          ]
        }
    """.trimIndent()

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        repository = FakeLeakGuardRepository()
        simulatedTimeMs = 100_000L

        val observeUseCase = ObserveLeakGuardUseCase(repository)
        val silenceUseCase = SilenceAlarmUseCase(repository)
        val unmuteUseCase = UnmuteAlarmUseCase(repository)
        val getStatusUseCase = GetDeviceStatusUseCase(repository)
        val getHistoryUseCase = GetDeviceHistoryUseCase(repository)

        viewModel = DashboardViewModel(
            observeLeakGuardUseCase = observeUseCase,
            silenceAlarmUseCase = silenceUseCase,
            unmuteAlarmUseCase = unmuteUseCase,
            getDeviceStatusUseCase = getStatusUseCase,
            getDeviceHistoryUseCase = getHistoryUseCase,
            repository = repository,
            timeProvider = { simulatedTimeMs }
        )
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `connect on init sets connection state to Connected and triggers auto GET_STATUS when subscriptions confirmed`() = runTest {
        runCurrent()
        assertEquals(ConnectionState.Connected, viewModel.uiState.value.connectionState)
        assertTrue(repository.requestStatusCalled)
        assertTrue(viewModel.uiState.value.isStatusRequestPending)
    }

    @Test
    fun `manual refreshStatus invokes GET_STATUS on repository`() = runTest {
        runCurrent()
        repository.requestStatusCalled = false
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        viewModel.refreshStatus()
        runCurrent()

        assertTrue(repository.requestStatusCalled)
        assertTrue(viewModel.uiState.value.isStatusRequestPending)
    }

    @Test
    fun `manual requestHistory invokes GET_HISTORY on repository`() = runTest {
        runCurrent()
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        viewModel.requestHistory()
        runCurrent()

        assertTrue(repository.requestHistoryCalled)
        assertTrue(viewModel.uiState.value.isHistoryRequestPending)
    }

    @Test
    fun `receiving non-retained real history JSON confirms request and updates UI state`() = runTest {
        runCurrent()
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        viewModel.requestHistory()
        runCurrent()
        assertTrue(viewModel.uiState.value.isHistoryRequestPending)

        simulatedTimeMs += 500L
        repository.emitIncomingMessage(
            MqttMessage(
                topic = MqttConfig.HISTORY_TOPIC,
                payload = realHistoryJson,
                isRetained = false,
                receivedAtMillis = simulatedTimeMs,
                receivedAtMonotonic = simulatedTimeMs
            )
        )
        runCurrent()

        assertFalse(viewModel.uiState.value.isHistoryRequestPending)
        assertEquals("Resposta do histórico recebida", viewModel.uiState.value.historyResponseMessage)
    }

    @Test
    fun `old retained history message does not confirm pending history request`() = runTest {
        runCurrent()
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        viewModel.requestHistory()
        runCurrent()

        repository.emitIncomingMessage(
            MqttMessage(
                topic = MqttConfig.HISTORY_TOPIC,
                payload = realHistoryJson,
                isRetained = true,
                receivedAtMillis = simulatedTimeMs - 1000L,
                receivedAtMonotonic = simulatedTimeMs - 1000L
            )
        )
        runCurrent()

        assertTrue(viewModel.uiState.value.isHistoryRequestPending)
        assertEquals(null, viewModel.uiState.value.historyResponseMessage)
    }

    @Test
    fun `duplicate history request is ignored while pending`() = runTest {
        runCurrent()
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        repository.requestHistoryCalled = false
        viewModel.requestHistory()
        runCurrent()

        assertTrue(repository.requestHistoryCalled)
        repository.requestHistoryCalled = false

        viewModel.requestHistory()
        runCurrent()

        assertFalse(repository.requestHistoryCalled)
    }

    @Test
    fun `LWT online status without live telemetry sets DESCONHECIDO`() = runTest {
        runCurrent()
        repository.emitEsp32LwtStatus(Esp32ConnectionStatus(isOnline = true, isRetained = false, receivedAtMillis = simulatedTimeMs, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        val state = viewModel.uiState.value
        assertEquals(ConnectionState.Connected, state.connectionState)
        assertEquals(DeviceAvailability.DESCONHECIDO, state.deviceAvailability)
    }

    @Test
    fun `LWT offline status immediately sets OFFLINE and recovers when newer live telemetry arrives`() = runTest {
        runCurrent()
        // Live telemetry
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()
        assertEquals(DeviceAvailability.ONLINE, viewModel.uiState.value.deviceAvailability)

        // LWT offline received at t = +500
        simulatedTimeMs += 500L
        repository.emitEsp32LwtStatus(Esp32ConnectionStatus(isOnline = false, isRetained = false, receivedAtMillis = simulatedTimeMs, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        assertEquals(DeviceAvailability.OFFLINE, viewModel.uiState.value.deviceAvailability)

        // Recovery: new live telemetry received at t = +1000
        simulatedTimeMs += 500L
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()

        assertEquals(DeviceAvailability.ONLINE, viewModel.uiState.value.deviceAvailability)
    }

    @Test
    fun `old out of order LWT offline message does not override newer live telemetry`() = runTest {
        runCurrent()
        // Live telemetry received at t = 100_000
        repository.emitState(LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs))
        runCurrent()
        assertEquals(DeviceAvailability.ONLINE, viewModel.uiState.value.deviceAvailability)

        // Out-of-order LWT offline received at t = 100_500, but with timestamp 90_000 (older than live telemetry)
        repository.emitEsp32LwtStatus(Esp32ConnectionStatus(isOnline = false, isRetained = false, receivedAtMillis = 90_000L, receivedAtMonotonic = 90_000L))
        runCurrent()

        // Status remains ONLINE because live telemetry is newer
        assertEquals(DeviceAvailability.ONLINE, viewModel.uiState.value.deviceAvailability)
    }

    @Test
    fun `telemetry older than 10 seconds transitions to SEM_SINAL using monotonic clock`() = runTest {
        runCurrent()
        repository.emitState(
            LeakGuardState(waterDetected = false, buzzerActive = false, muted = false, receivedAt = simulatedTimeMs, isRetained = false, receivedAtMonotonic = simulatedTimeMs)
        )
        runCurrent()
        assertEquals(DeviceAvailability.ONLINE, viewModel.uiState.value.deviceAvailability)

        simulatedTimeMs += 15_000L
        viewModel.recalculateAndEmitState()
        runCurrent()

        val state = viewModel.uiState.value
        assertEquals(DeviceAvailability.SEM_SINAL, state.deviceAvailability)
        assertFalse(state.isDeviceOnline)
    }
}
