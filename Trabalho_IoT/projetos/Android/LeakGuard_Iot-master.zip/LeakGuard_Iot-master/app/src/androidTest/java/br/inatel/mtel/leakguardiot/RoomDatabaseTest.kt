package br.inatel.mtel.leakguardiot

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.inatel.mtel.leakguardiot.data.local.LeakGuardDatabase
import br.inatel.mtel.leakguardiot.data.local.entity.LeakEventEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RoomDatabaseTest {

    private lateinit var context: Context
    private lateinit var inMemoryDb: LeakGuardDatabase

    private val deviceId = "jgocana-yverdecia-iot-device01"

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        inMemoryDb = Room.inMemoryDatabaseBuilder(
            context,
            LeakGuardDatabase::class.java
        ).allowMainThreadQueries().build()
    }

    @After
    fun tearDown() {
        inMemoryDb.close()
    }

    @Test
    fun testInMemoryRoomDatabase_InsertQueryAndDeduplication() = runBlocking {
        val dao = inMemoryDb.leakEventDao()

        // 1. Insert incident
        val incident1 = LeakEventEntity(
            deviceId = deviceId,
            eventId = 1L,
            startedAtUnix = 1794064500L,
            endedAtUnix = 1794064530L,
            durationSeconds = 30L
        )
        val rowId1 = dao.insertIncident(incident1)
        assertEquals(1L, rowId1)

        // 2. Query incident from DAO
        val queried = dao.getIncidentByDeviceAndEventId(deviceId, 1L)
        assertNotNull(queried)
        assertEquals(30L, queried?.durationSeconds)

        // 3. Insert duplicate incident with same deviceId and eventId
        val duplicateIncident = LeakEventEntity(
            deviceId = deviceId,
            eventId = 1L,
            startedAtUnix = 1794064500L,
            endedAtUnix = 1794064999L, // different end time
            durationSeconds = 999L
        )
        val rowIdDup = dao.insertIncident(duplicateIncident)
        assertEquals(-1L, rowIdDup) // IGNORE strategy returns -1 on conflict

        // 4. Verify count is still 1 and original record was preserved
        val count = dao.getIncidentCount(deviceId)
        assertEquals(1, count)
        val afterDup = dao.getIncidentByDeviceAndEventId(deviceId, 1L)
        assertEquals(30L, afterDup?.durationSeconds) // Original preserved

        // 5. Insert additional incidents
        val incident2 = LeakEventEntity(
            deviceId = deviceId,
            eventId = 2L,
            startedAtUnix = 1794064700L,
            endedAtUnix = 1794064745L,
            durationSeconds = 45L
        )
        dao.insertIncident(incident2)

        // 6. Check total count, duration sum, longest incident
        assertEquals(2, dao.getIncidentCount(deviceId))
        assertEquals(75L, dao.getTotalDurationSeconds(deviceId))

        val longest = dao.getLongestIncident(deviceId)
        assertNotNull(longest)
        assertEquals(2L, longest?.eventId)
        assertEquals(45L, longest?.durationSeconds)

        // 7. Observe Flow query
        val flowList = dao.observeIncidentsByDevice(deviceId).first()
        assertEquals(2, flowList.size)
    }

    @Test
    fun testPersistentFileRoomDatabase_RecordsSurviveCloseAndReopen() = runBlocking {
        val dbFile = "test_persistent_room.db"
        context.deleteDatabase(dbFile)

        // Open persistent database and insert incident
        var persistentDb = Room.databaseBuilder(
            context,
            LeakGuardDatabase::class.java,
            dbFile
        ).allowMainThreadQueries().build()

        val dao1 = persistentDb.leakEventDao()
        dao1.insertIncident(
            LeakEventEntity(
                deviceId = deviceId,
                eventId = 10L,
                startedAtUnix = 1794065000L,
                endedAtUnix = 1794065060L,
                durationSeconds = 60L
            )
        )
        assertEquals(1, dao1.getIncidentCount(deviceId))

        // Close database
        persistentDb.close()

        // Re-open persistent database from file
        persistentDb = Room.databaseBuilder(
            context,
            LeakGuardDatabase::class.java,
            dbFile
        ).allowMainThreadQueries().build()

        val dao2 = persistentDb.leakEventDao()
        val count = dao2.getIncidentCount(deviceId)
        val record = dao2.getIncidentByDeviceAndEventId(deviceId, 10L)

        // Verify record survived close and re-open
        assertEquals(1, count)
        assertNotNull(record)
        assertEquals(60L, record?.durationSeconds)

        // Clean up
        persistentDb.close()
        context.deleteDatabase(dbFile)
    }
}
